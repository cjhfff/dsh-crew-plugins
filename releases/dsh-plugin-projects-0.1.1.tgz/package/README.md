# DSH Projects

DSH `0.2.1-rc.5` 的项目、看板、交付、公开工作流配方和定时插件。Host、浏览器模块、Remote 描述及 bundle patch 均在此包内，不需要修改 DSH 源码或 runtime。

## 使用

安装后点击左栏「项目与交付」。填写名称和一句需求，插件创建目录、注册官方 Workspace、创建主 Session 并发送需求。项目详情展示公开 plan/todo、委派进度、交付文件、自测结果和人工确认项；「打开会话」进入原生 DSH 会话。

在已完成的项目上「保存为配方」，保存实际公开委派步骤及其观察到的先后关系。新项目可选择「作为参考」或「固定执行」。参考模式将配方放入主会话开场上下文；固定模式调用该 Agent 的官方 workflow engine。没有可恢复任务的配方不能固定执行。公开生命周期不能还原原脚本的完整 DAG，保存的是实际观察到的完成先于启动关系；并行任务保留为无依赖步骤。配方支持重命名、删除及 JSON 文件导入导出。

定时支持每天、每周、每 N 小时、cron 和延时一次。固定项目追加通过官方 schedule 向其主 Session 投递；若指定配方，则提醒模型调用 `projects_run_recipe` 实际执行。每次新建使用一个独立调度 Session，定时提示模型调用 `projects_create`。这两种配方调度依赖模型成功调用工具；插件不会把提示投递成功当成项目运行成功。按官方消息 ID 防止同一提醒被重复调用；进程若恰在项目创建与幂等记录落盘之间崩溃，恢复时仍存在重复创建的窗口。可在定时列表删除原生任务。

## 安装与回滚

下列命令是待管理员执行的正式操作；本任务仅在临时 profile 实测。

```powershell
dsh plugin --profile web add <path>/dsh-plugin-projects-0.1.1.tgz
dsh --profile web --dump-config
# 启动命令同样传入该 --patch，或将配置行合入实际 profile。

# 卸载撤销插件 UI / 工具 / Remote / 监听，不删除项目目录和官方 Session。
dsh plugin --profile web remove dsh-plugin-projects
```

卸载前在 Projects 定时页删除不再需要的任务；官方 schedule 的持久任务不归插件卸载自动删除。再次安装可复用插件 JSON 状态。删除项目文件、Workspace、Session 或插件状态需另行人工决定。

## 配置

`overlay/profiles/projects.patch.yml` 通过行 id `dsh-plugin-projects` 提供独立配置。DSH patch 覆盖整行 config，修改时应保留其他所需键。

| 键 | 默认值 | 用途 |
| --- | --- | --- |
| `projectsRoot` | `<DSH_HOME>/projects` | 项目根目录，必须为绝对路径 |
| `dataDir` | `<DSH_HOME>/projects-data` | 插件 `projects.json` 状态目录 |
| `leaderPreset` | `null` | 任务 X Leader 的公开 preset id；空值沿用默认 preset |
| `uiCheckCommand` | 包内 `tools/ui-check.mjs` | 已安装无头验收脚本路径 |
| `scheduleSessionTitle` | `Projects scheduler` | 调度 Session 标题 |

模型工具在 Agent 作用域安装：

- `ui_check`：当前项目根目录、JSON 步骤数组字符串、可选页面/结果文件/截图路径。调用现有脚本和本机 Edge/Chrome，使用 headless、隐藏子进程及 `NO_PROXY=*`，不下载浏览器。完整 JSON 结果回到会话。
- `projects_deliver`：当前项目交付总结、自测结果、人工确认项。自测缺省不声明通过。
- `projects_create`：调度会话按需求创建新项目；可带配方及 reference/fixed 选择。
- `projects_run_recipe`：在固定项目的到期提醒中，按 scheduleId 执行其保存的配方。

原生 `deliverables/presented` 继续由 DSH 展示，插件将其公开文件记录折叠到项目交付卡片。未实际运行测试的自动卡片不会声明测试通过。

## 构建与验证

发布目录已包含 `lib/index.js`、官方 ModuleLoader 浏览器模块、Typert Host/Remote 描述和声明文件。源码使用 TypeScript；构建脚本只写本包 `lib/`。

```powershell
# 在本目录安装开发依赖后构建
npm install --ignore-scripts
npm run build

# 从 DSH 根目录运行
node overlay/smoke/projects/projects.mjs
node --test overlay/smoke/projects/core.test.mjs
node overlay/smoke/projects/live.mjs
```

