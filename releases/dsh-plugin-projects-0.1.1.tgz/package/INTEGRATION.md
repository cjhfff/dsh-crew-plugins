# Projects 集成登记（供 overlay 维护者合并）

本任务只增加 Projects 自有目录和 `profiles/projects.patch.yml`。未改其他 profile、`compat-lock.json` 或 overlay README，未安装到正式 3080。下面内容需由主维护者登记。

## 建议登记

- 包：`overlay/plugins/dsh-plugin-projects`，版本 `0.1.0`。
- DSH：精确锁定 `0.2.1-rc.5`，Node `>=22.19.0`。
- 类型：官方 bundle，`dsh.bundle.patch: ./cordis.patch.yml`。
- Host：`.` → `lib/index.js`；浏览器：`./client` → `lib/client.js`，`dsh.client.platform: web`；协议：`./typert` 与 `./remote`。
- 配置层：`overlay/profiles/projects.patch.yml`，在 bundle 后应用；若要使用任务 X Leader，将 `leaderPreset` 设置为其实际 id，插件不硬编码 Crew 实现。
- 持久状态：`overlay/state/projects/projects.json`；默认项目根：`<DSH_HOME>/projects`。

## 公开扩展点

| 功能 | 官方接口与作用域 |
| --- | --- |
| 项目目录与 Workspace | `workspaceRegistry.create(path, title)` |
| 主会话 | `sessionController.create({workspaceId, agentPreset?})`、`resolveAgent`、Agent `followup` |
| 看板 | `sessionProjections.register`，Zod wire schema；公开 `session/event` 增量折叠 |
| 文件交付 | `deliverables/presented`；补充插件交付工具 |
| 模型工具 | 具体 Agent 上 `tools.register(defineTool(...))`，Cordis 卸载撤销 |
| 固定配方 | 目标 Agent 的 delegation scope 中 `workflowEngine.start`，运行结束后 dispose |
| 定时 | `schedule.create/list/delete`，原生定时 Session 投递 |
| Remote | `TypertRemoteService` namespace `projects`，`@Remote` 方法，typert-loader 加载包 metadata |
| UI | 官方 `sidebar.panellist` 入口 + keyed `main` slot；不替换 Workspace 浏览器 |

浏览器通过 scoped `ctx.remote.$mount` 注册本包的 Remote 描述，Cordis effect 管理挂载、样式和 slots。没有全局 action/Remote 对象。UI 使用 DSH 主题变量，打开会话使用 `uiWorkspace.openSession`。

## 数据与降级边界

看板和配方只使用公开事件/公开子会话任务，不读取隐藏推理。生命周期不包含原脚本 DAG，因此配方依赖是观察到的完成先于启动约束。缺少任务内容或存在非法依赖的导入不能安全固定回放，应明确返回错误。

官方 schedule 只能向现有 Session 投递。`target: new` 采用任务允许的降级：一个可使用 `projects_create` 的调度 Session，到期收到明确建项目指令，再创建独立 Workspace/主 Session。`append + recipeId` 在原项目 Session 提醒调用 `projects_run_recipe`，真实调用 workflow。两者按官方提醒消息 ID 去重，且校验调用方 Session；进程在创建项目与记录幂等结果之间崩溃时仍有重复创建窗口。新项目是否真正生成必须以项目记录和新 Session 为证，不能只看定时提示已投递。

安装和卸载使用 `dsh plugin --profile <profile> add <包路径>` / `remove dsh-plugin-projects`。正式 3080 的启动/重载由主维护者按其流程执行。卸载前删除 Projects 创建的官方定时；卸载不自动删除官方 Workspace、Session、项目文件或插件 JSON。

## 可合并的 README 段落

> Projects 插件在 DSH 左栏提供「项目与交付」：一句需求创建 Workspace 和主会话，查看公开计划/待办与交付卡片，模型可调用本机无头验收。已完成项目可保存公开委派配方，新项目选择参考或固定执行，并通过 DSH 原生定时追加已有项目或触发新项目。配置见 `profiles/projects.patch.yml`；Leader preset id 由配置提供。安装、卸载和限制见插件 README，实际验收记录见 Projects delivery.md。
