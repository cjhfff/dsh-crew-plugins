import type { BoardState, DeliveryCard, ProjectStatus, PublicWorkflowEvent, RecipeRecord, RecipeStep } from './types.ts'

export const EMPTY_BOARD: BoardState = { plan: [], todos: [], deliverables: [], workflow: [] }

/**
 * A todo/write event stores the complete replacement list below `data.todos`.
 * Keep the fold tolerant of future public todo fields while copying the value so
 * a projection never aliases the event log's mutable object.
 */
function todoSnapshot(data: unknown): readonly unknown[] | undefined {
  if (data === null || typeof data !== 'object') return undefined
  const todos = (data as Record<string, unknown>).todos
  return Array.isArray(todos) ? structuredClone(todos) : undefined
}

/** Convert a user-visible name into a stable directory component. */
export function slugify(value: string): string {
  const slug = value.normalize('NFKC').trim().toLowerCase()
    .replace(/[^\p{Letter}\p{Number}]+/gu, '-').replace(/^-+|-+$/g, '').slice(0, 64)
  return /^(con|prn|aux|nul|com[1-9]|lpt[1-9])$/i.test(slug) ? `project-${slug}` : slug || 'project'
}

export function publicWorkflowEvent(event: unknown): PublicWorkflowEvent | undefined {
  if (event === null || typeof event !== 'object') return undefined
  const value = event as Record<string, unknown>
  const rawType = typeof value.type === 'string' ? value.type : ''
  // The workflow engine's live events are not Session events.  The
  // model-facing tool persists their public lifecycle as tool-workflow/*
  // records, with the payload nested under `data`; accept both forms so
  // boards can be rebuilt from a cold Session history as well as live events.
  const data = value.data && typeof value.data === 'object' ? value.data as Record<string, unknown> : value
  const type = rawType === 'subagent/catalog' ? 'workflow/agent-start'
    : rawType === 'tool-workflow/run-start' ? 'workflow/start'
    : rawType === 'tool-workflow/run-end' ? 'workflow/end'
      : rawType.startsWith('tool-workflow/') ? `workflow/${rawType.slice('tool-workflow/'.length)}` : rawType
  if (!/^workflow\/(start|phase|log|agent-start|agent-end|end)$/.test(type)) return undefined
  return {
    type,
    ...(typeof data.runId === 'string' ? { runId: data.runId } : {}),
    ...(typeof data.childId === 'string' ? { childId: data.childId } : {}),
    ...(typeof data.label === 'string' ? { label: data.label } : {}),
    ...(typeof data.name === 'string' ? { label: data.name } : {}),
    ...(typeof data.phase === 'string' ? { phase: data.phase } : {}),
    ...(typeof data.status === 'string' ? { status: data.status } : {}),
    ...(typeof data.stopReason === 'string' ? { status: data.stopReason } : {}),
    ...(typeof data.time === 'string' ? { at: data.time } : {}),
    ...(typeof data.detail === 'string' ? { detail: data.detail } : {}),
    ...(typeof data.seq === 'number' ? { seq: data.seq } : {}),
    ...(typeof data.outcome === 'string' ? { status: data.outcome } : {}),
    ...(typeof data.task === 'string' ? { task: data.task } : {}),
    ...(typeof data.actor === 'string' ? { actor: data.actor } : {}),
    ...(rawType === 'subagent/catalog' ? { detail: 'public subagent/catalog' } : {}),
  }
}

/** Fold only public projection/event shapes; no transcript or model internals enter a board. */
export function foldBoard(state: BoardState, event: unknown): BoardState {
  if (event === null || typeof event !== 'object') return state
  const value = event as Record<string, unknown>
  if (value.type === 'todo/write') {
    const todos = todoSnapshot(value.data)
    if (todos !== undefined) return { ...state, todos }
  }
  if (value.type === 'plan/mode' && value.data && typeof value.data === 'object') {
    return { ...state, plan: [structuredClone(value.data)] }
  }
  if (value.type === 'deliverables/presented' && value.data && typeof value.data === 'object') {
    const files = (value.data as Record<string, unknown>).files
    if (Array.isArray(files)) {
      const merged = new Map(state.deliverables.map(file => [file.path, file]))
      for (const file of files) if (file && typeof file === 'object' && typeof file.path === 'string') merged.set(file.path, structuredClone(file))
      return { ...state, deliverables: [...merged.values()] }
    }
  }
  const workflow = publicWorkflowEvent(event)
  if (workflow !== undefined) {
    const duplicate = state.workflow.some(item => item.type === workflow.type && item.runId === workflow.runId && item.childId === workflow.childId && item.seq === workflow.seq && item.label === workflow.label)
    return duplicate ? state : { ...state, workflow: [...state.workflow, workflow].slice(-2000) }
  }
  return state
}

export function statusFromPublicState(running: boolean, waiting: boolean, delivered: boolean, failed = false): ProjectStatus {
  if (failed) return 'failed'
  if (delivered) return 'delivered'
  if (running) return 'running'
  if (waiting) return 'waiting'
  return 'running'
}

/** Build a recipe from public workflow lifecycle records, preserving dependency order. */
export function recipeFromEvents(name: string, events: readonly PublicWorkflowEvent[], sourceProjectId?: string): RecipeRecord {
  const steps: RecipeStep[] = []
  const completed = new Set<string>()
  const starts = new Map<string, string>()
  const children = new Set<string>()
  const workflowChildren = new Set(events.filter(event => event.type === 'workflow/agent-start' && event.detail !== 'public subagent/catalog').flatMap(event => event.childId === undefined ? [] : [event.childId]))
  for (const [index, event] of events.entries()) {
    const key = `${event.runId ?? 'run'}-${event.childId ?? event.seq ?? index}`
    if (event.type === 'workflow/agent-end') {
      const id = starts.get(key) ?? starts.get(`${event.runId ?? 'run'}-${event.seq}`)
      if (id !== undefined) completed.add(id)
      continue
    }
    if (event.type !== 'workflow/agent-start') continue
    if (event.childId !== undefined && (children.has(event.childId) || event.detail === 'public subagent/catalog' && workflowChildren.has(event.childId))) continue
    if (event.childId !== undefined) children.add(event.childId)
    const id = key.replace(/[^\w.-]+/g, '-')
    const step: RecipeStep = {
      id, kind: 'agent', label: event.label ?? event.phase ?? event.runId ?? 'workflow step',
      // Public lifecycle events do not expose the script's DAG. These are
      // exactly the observed completed-before-start constraints; overlapping
      // members remain independent instead of inventing a serial dependency.
      dependsOn: [...completed], publicEvent: event.detail === 'public subagent/catalog' ? 'subagent/catalog' : event.type,
      ...(event.task === undefined ? {} : { task: event.task }),
      ...(event.actor === undefined ? {} : { actor: event.actor }),
      ...(event.phase === undefined ? {} : { phase: event.phase }),
      ...(event.childId === undefined ? {} : { sourceSessionId: event.childId }),
    }
    steps.push(step); starts.set(key, id); if (event.seq !== undefined) starts.set(`${event.runId ?? 'run'}-${event.seq}`, id)
  }
  const now = new Date().toISOString()
  return {
    id: `recipe-${slugify(name)}-${Date.now().toString(36)}`,
    name: name.trim() || 'Unnamed recipe',
    description: 'Public delegation tasks with observed completed-before-start dependencies',
    steps,
    ...(sourceProjectId === undefined ? {} : { sourceProjectId }),
    createdAt: now,
    updatedAt: now,
  }
}
export function deliveryCard(input: {
  projectId: string; name: string; path: string; files?: DeliveryCard['files']; selfTest?: DeliveryCard['selfTest']; summary?: string; humanChecks?: readonly string[]
}): DeliveryCard {
  return {
    projectId: input.projectId, title: `${input.name} delivery`,
    summary: input.summary ?? 'The project session is complete; delivery files and self-test results are shown below.',
    openPath: input.path,
    selfTest: input.selfTest ?? { passed: false }, files: input.files ?? [],
    humanChecks: input.humanChecks ?? ['Open the page manually and confirm its visual result and requirement details.'],
    createdAt: new Date().toISOString(),
  }
}
