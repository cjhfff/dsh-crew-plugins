/** DSH Projects Host plugin: workspace/session ownership, public boards, recipes and schedules. */
import { randomUUID } from 'node:crypto'
import { spawn } from 'node:child_process'
import { mkdir, readFile, realpath, rename, rm, writeFile } from 'node:fs/promises'
import { dirname, isAbsolute, join, relative, resolve } from 'node:path'
import type { Context } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import { z as zod } from 'zod'
import { createUserMessage } from '@deepseek-ai/dsh-llm'
import { Remote, TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol'
import { defineTool } from '@deepseek-ai/dsh-tools'
import { deliveryCard, EMPTY_BOARD, foldBoard, recipeFromEvents, slugify, statusFromPublicState } from './core.ts'
import type { BoardState, DeliveryCard, ProjectRecord, ProjectsConfig, RecipeRecord, RecipeUse, ScheduleRecord } from './types.ts'

export type * from './types.ts'

declare module '@deepseek-ai/cordis' {
  interface Context { projects: ProjectsService }
}

interface StateFile {
  projects: ProjectRecord[]
  recipes: RecipeRecord[]
  schedules: ScheduleRecord[]
  schedulerSessionId?: string
}

const DEFAULT_ROOT = (process.env.DSH_HOME || (process.env.USERPROFILE || process.env.HOME || '.') + '/.dsh') + '/projects'
const DEFAULT_DATA = (process.env.DSH_HOME || (process.env.USERPROFILE || process.env.HOME || '.') + '/.dsh') + '/projects-data'
const DEFAULT_UI_CHECK = decodeURIComponent(new URL('../tools/ui-check.mjs', import.meta.url).pathname).replace(/^\/([A-Za-z]:)/, '$1')

function emptyState(): StateFile { return { projects: [], recipes: [], schedules: [] } }
function now(): string { return new Date().toISOString() }
function text(value: unknown, field: string): string {
  if (typeof value !== 'string' || value.trim() === '') throw new Error(`${field} must be a non-empty string`)
  return value.trim()
}
function inside(root: string, target: string): boolean {
  const r = resolve(root), t = resolve(target)
  return t === r || relative(r, t) !== '' && !relative(r, t).startsWith('..') && !isAbsolute(relative(r, t))
}
function publicSnapshot(record: ProjectRecord): ProjectRecord {
  return structuredClone(record)
}
function publicText(content: unknown): string {
  if (typeof content === 'string') return content
  if (!Array.isArray(content)) return ''
  return content.filter(block => block && block.type === 'text' && typeof block.text === 'string').map(block => block.text).join('\n')
}
function replacePath(value: string, from: string, to: string): string {
  return value.replaceAll(from, to).replaceAll(from.replaceAll('\\', '/'), to).replaceAll(from.replaceAll('/', '\\'), to)
}
function validatedRecipe(input: unknown): RecipeRecord {
  const short = zod.string().min(1).max(500)
  const schema = zod.object({
    id: short, name: short, description: zod.string().max(10000),
    steps: zod.array(zod.object({
      id: short, kind: zod.enum(['agent', 'workflow', 'phase', 'log']), label: short,
      dependsOn: zod.array(short).max(500), publicEvent: short,
      task: zod.string().max(200000).optional(), actor: short.optional(), phase: short.optional(), sourceSessionId: short.optional(),
    })).max(500),
    sourceProjectId: short.optional(), createdAt: short, updatedAt: short,
  })
  const value = schema.parse(input)
  const byId = new Map(value.steps.map(step => [step.id, step]))
  if (byId.size !== value.steps.length) throw new Error('Recipe step ids must be unique')
  const visiting = new Set<string>(), complete = new Set<string>()
  const visit = (id: string): void => {
    if (complete.has(id)) return
    if (visiting.has(id)) throw new Error('Recipe dependencies must not contain a cycle')
    const step = byId.get(id); if (step === undefined) throw new Error(`Unknown recipe dependency: ${id}`)
    visiting.add(id); for (const dep of step.dependsOn) visit(dep); visiting.delete(id); complete.add(id)
  }
  for (const step of value.steps) visit(step.id)
  return value
}

export interface CreateProjectRequest { readonly name: string; readonly prompt: string; readonly recipeId?: string; readonly recipeUse?: RecipeUse }
export interface ProjectIdRequest { readonly projectId: string }
export interface SaveRecipeRequest { readonly projectId: string; readonly name?: string; readonly description?: string }
export interface RenameRecipeRequest { readonly recipeId: string; readonly name?: string; readonly description?: string }
export interface RunRecipeRequest { readonly recipeId: string; readonly use: RecipeUse; readonly projectId?: string; readonly prompt?: string }
export interface ScheduleProjectRequest {
  readonly projectId?: string
  readonly recipeId?: string
  readonly recipeUse?: RecipeUse
  readonly title?: string
  readonly prompt?: string
  readonly target?: 'append' | 'new'
  readonly after_seconds?: number
  readonly every_seconds?: number
  readonly daily?: unknown
  readonly weekly?: unknown
  readonly cron?: string | { readonly expression: string; readonly time_zone: string }
}
export interface UiCheckRequest { readonly root: string; readonly steps: string | readonly unknown[]; readonly page?: string; readonly out?: string; readonly shot?: string }

/** Host Remote and model-facing tool owner. */
export class ProjectsService extends TypertRemoteService {
  // These services are part of the public DSH composition.  Declaring them in
  // the injection list makes plugin startup deterministic and avoids silently
  // loading a Projects UI that cannot create schedules or fixed workflows.
  static inject = ['agents', 'sessionController', 'workspaceRegistry', 'sessionProjections', 'schedule', 'typert']
  static Config: z<ProjectsConfig> = z.object({
    projectsRoot: z.string().default(DEFAULT_ROOT),
    dataDir: z.string().default(DEFAULT_DATA),
    leaderPreset: z.union([z.string(), z.const(null)]).default(null),
    uiCheckCommand: z.string().default(DEFAULT_UI_CHECK),
    scheduleSessionTitle: z.string().default('Projects scheduler'),
    uiCheckTimeoutMs: z.natural().min(1000).default(120000),
  })

  readonly config: Required<ProjectsConfig>
  private readonly statePath: string
  private state: StateFile = emptyState()
  private ready: Promise<void>
  private writeTail: Promise<void> = Promise.resolve()
  private schedulerReady?: Promise<string>
  private dispatchTail: Promise<unknown> = Promise.resolve()
  private readonly installedAgents = new WeakSet<object>()
  private readonly workflowProjects = new Map<string, string>()
  private readonly tasks = new Set<Promise<unknown>>()
  private readonly activeRuns = new Set<any>()
  private readonly uiChecks = new Set<AbortController>()

  constructor(ctx: Context, config: ProjectsConfig = {}) {
    super(ctx, 'projects', { namespace: 'projects' })
    this.config = {
      projectsRoot: config.projectsRoot ?? DEFAULT_ROOT,
      dataDir: config.dataDir ?? DEFAULT_DATA,
      leaderPreset: config.leaderPreset ?? null,
      uiCheckCommand: config.uiCheckCommand ?? DEFAULT_UI_CHECK,
      scheduleSessionTitle: config.scheduleSessionTitle ?? 'Projects scheduler',
      uiCheckTimeoutMs: config.uiCheckTimeoutMs ?? 120000,
    }
    if (!isAbsolute(this.config.projectsRoot) || !isAbsolute(this.config.dataDir)) throw new Error('Projects paths must be absolute')
    this.statePath = join(this.config.dataDir, 'projects.json')
    this.ready = this.load()
    this.installProjection()
    ctx.on('session/event', (session: any, event: any) => {
      void this.onSessionEvent(session, event).catch(error => this.ctx.logger.warn(`projects: session event update failed: ${String(error)}`))
    }, { global: true })
    ctx.on('agent/status', ({ agent, status }: any) => {
      void this.onAgentStatus(agent?.id, status).catch(error => this.ctx.logger.warn(`projects: status update failed: ${String(error)}`))
    }, { global: true })
    ctx.on('agent/created', ({ agent }: any) => this.installAgentTools(agent), { global: true })
    for (const agent of (ctx as any).agents.list()) this.installAgentTools(agent)
    this.installWorkflowEvents()
    ctx.effect(() => async () => {
      for (const controller of this.uiChecks) controller.abort(new Error('Projects plugin unloaded'))
      for (const run of this.activeRuns) run.cancel('Projects plugin unloaded')
      await Promise.allSettled([...this.tasks, ...[...this.activeRuns].map(run => run.dispose()), this.writeTail])
    }, 'projects: drain owned operations')
  }

  private async load(): Promise<void> {
    await mkdir(this.config.dataDir, { recursive: true })
    try {
      const parsed = JSON.parse(await readFile(this.statePath, 'utf8')) as Partial<StateFile>
      this.state = {
        projects: Array.isArray(parsed.projects) ? parsed.projects : [],
        recipes: Array.isArray(parsed.recipes) ? parsed.recipes : [],
        schedules: Array.isArray(parsed.schedules) ? parsed.schedules : [],
        ...(typeof parsed.schedulerSessionId === 'string' ? { schedulerSessionId: parsed.schedulerSessionId } : {}),
      }
    } catch (error: any) {
      if (error?.code !== 'ENOENT') throw new Error(`Projects state could not be loaded: ${String(error)}`)
    }
  }

  private async save(): Promise<void> {
    const write = this.writeTail.then(async () => {
      const tmp = `${this.statePath}.${process.pid}.${randomUUID()}.tmp`
      await mkdir(dirname(this.statePath), { recursive: true })
      await writeFile(tmp, JSON.stringify(this.state, null, 2), 'utf8')
      await rename(tmp, this.statePath)
    })
    this.writeTail = write.catch(() => undefined)
    await write
  }

  private installProjection(): void {
    const projections = (this.ctx as any).sessionProjections
    if (projections === undefined || typeof projections.register !== 'function') return
    this.ctx.effect(() => projections.register({
      key: 'projectsBoard', stateVersion: 2, stateSchema: zod.any(),
      init: () => structuredClone(EMPTY_BOARD),
      apply: (state: BoardState, event: unknown) => foldBoard(state, event),
      wire: { viewSchema: zod.any(), view: (state: BoardState) => state },
    }), 'dsh-projects.session-projection')
  }

  private async onSessionEvent(session: any, event: any): Promise<void> {
    await this.ready
    const project = this.projectForSession(session)
    if (project === undefined) return
    const isMainSession = session?.id === project.sessionId
    if (!isMainSession && ['todo/write', 'plan/mode'].includes(event?.type)) return
    const publicEvent = !isMainSession && event?.type === 'turn/end' ? { type: 'workflow/agent-end', data: { childId: session.id, status: event.data?.reason?.kind } } : event
    const board = foldBoard(project.board ?? EMPTY_BOARD, publicEvent)
    const delivered = board.deliverables.length > 0 && event?.type === 'deliverables/presented'
    let status = delivered ? 'delivered' : project.status
    if (isMainSession && event?.type === 'turn/end' && event.data?.reason?.kind === 'error') status = 'failed'
    if (isMainSession && event?.type === 'turn/end' && event.data?.reason?.kind === 'blocked') status = 'waiting'
    if (board === project.board && status === project.status) return
    const card = delivered ? deliveryCard({ projectId: project.id, name: project.name, path: project.path, files: board.deliverables, selfTest: project.delivery?.selfTest, summary: project.delivery?.summary, humanChecks: project.delivery?.humanChecks }) : project.delivery
    const next: ProjectRecord = { ...project, board, updatedAt: now(), status, ...(card === undefined ? {} : { delivery: card }) }
    this.state.projects = this.state.projects.map(item => item.id === project.id ? next : item)
    await this.save()
  }

  private async onAgentStatus(sessionId: string | undefined, status: string): Promise<void> {
    if (sessionId === undefined) return
    await this.ready
    const project = this.state.projects.find(item => item.sessionId === sessionId)
    if (project === undefined) return
    const running = status === 'running'
    const next: ProjectRecord = { ...project, status: running ? 'running' : project.status === 'failed' ? 'failed' : statusFromPublicState(false, true, project.delivery !== undefined), updatedAt: now(), ...(running ? { lastError: undefined } : {}) }
    this.state.projects = this.state.projects.map(item => item.id === project.id ? next : item)
    await this.save()
  }

  @Remote('list')
  async list(): Promise<readonly ProjectRecord[]> { await this.ready; return this.state.projects.map(publicSnapshot) }

  @Remote('get')
  async get(request: ProjectIdRequest): Promise<ProjectRecord> {
    await this.ready; const project = this.state.projects.find(item => item.id === request.projectId)
    if (project === undefined) throw new Error(`project not found: ${request.projectId}`)
    return publicSnapshot(project)
  }

  @Remote('create')
  async create(request: CreateProjectRequest): Promise<ProjectRecord> {
    await this.ready
    const name = text(request.name, 'name'), prompt = text(request.prompt, 'prompt')
    const slug = slugify(name), id = `project-${Date.now().toString(36)}-${randomUUID().slice(0, 8)}`
    if (request.recipeId !== undefined) this.requireRecipe(request.recipeId)
    if (request.recipeUse !== undefined && !['reference', 'fixed'].includes(request.recipeUse)) throw new Error('invalid recipe mode')
    const projectPath = await this.allocateProjectPath(slug)
    const workspace = await (this.ctx as any).workspaceRegistry.create(projectPath, name)
    const preset = this.config.leaderPreset ?? undefined
    const created = await (this.ctx as any).sessionController.create({ workspaceId: workspace.id ?? workspace.workspaceId, ...(preset === undefined ? {} : { agentPreset: preset }) })
    const sessionId = created.sessionId
    const record: ProjectRecord = {
      id, name, slug, path: projectPath, workspaceId: workspace.id ?? workspace.workspaceId, sessionId,
      prompt, createdAt: now(), updatedAt: now(), status: 'running', board: structuredClone(EMPTY_BOARD),
      ...(request.recipeId === undefined ? {} : { recipeId: request.recipeId }),
    }
    this.state.projects.push(record); await this.save()
    try {
      const agent = await this.resolveAgent(sessionId)
      if (request.recipeId !== undefined && request.recipeUse === 'fixed') {
        this.background(this.runRecipe({ recipeId: request.recipeId, use: 'fixed', projectId: id, prompt }).then(result => {
          agent.followup(createUserMessage({ content: [{ type: 'text', text: this.fixedReviewPrompt(record, result) }], source: { kind: 'user' } }))
        }), id)
      } else {
        const context = request.recipeId === undefined ? '' : await this.recipeContext(request.recipeId, 'reference')
        agent.followup(createUserMessage({ content: [{ type: 'text', text: `${this.openingPrompt(record)}${context}` }], source: { kind: 'user' } }))
      }
      return publicSnapshot(this.requireProject(id))
    } catch (error) {
      this.replaceProject(id, { status: 'failed', lastError: String(error) }); await this.save(); throw error
    }
  }

  @Remote('deliver')
  async deliver(request: ProjectIdRequest & { readonly summary?: string; readonly selfTest?: DeliveryCard['selfTest']; readonly humanChecks?: readonly string[] }): Promise<DeliveryCard> {
    await this.ready; const project = this.requireProject(request.projectId)
    const card = deliveryCard({ projectId: project.id, name: project.name, path: project.path, files: project.board.deliverables, summary: request.summary ?? project.delivery?.summary, selfTest: request.selfTest ?? project.delivery?.selfTest, humanChecks: request.humanChecks ?? project.delivery?.humanChecks })
    this.state.projects = this.state.projects.map(item => item.id === project.id ? { ...item, status: 'delivered', delivery: card, updatedAt: now() } : item)
    await this.save(); return card
  }

  @Remote('saveRecipe')
  async saveRecipe(request: SaveRecipeRequest): Promise<RecipeRecord> {
    await this.ready; const project = this.requireProject(request.projectId)
    const events = [...project.board.workflow]
    for (let index = 0; index < events.length; index++) {
      const event = events[index]
      if (event.type !== 'workflow/agent-start' || event.childId === undefined) continue
      try {
        const snapshot = await (this.ctx as any).sessionController.inspect(event.childId)
        const message = snapshot.events.find((item: any, index: number) => item.type === 'user/message' && (item.seq ?? index) >= (snapshot.inheritedEventCount ?? 0))
        const task = publicText(message?.data?.content)
        const title = snapshot.events.find((item: any) => item.type === 'session/title')?.data?.title
        events[index] = { ...event, ...(task ? { task: replacePath(task, project.path, '{{PROJECT_ROOT}}') } : {}), actor: title || event.label || 'Agent' }
      } catch { /* A public label remains available when an external child has no local Session. */ }
    }
    const recipe = recipeFromEvents(request.name ?? `${project.name} recipe`, events, project.id)
    if (recipe.steps.length === 0) throw new Error('This project has no public delegation or workflow member events to save as a recipe.')
    const value = { ...recipe, ...(request.description === undefined ? {} : { description: request.description }) }
    this.state.recipes = [...this.state.recipes.filter(item => item.id !== recipe.id), value]; await this.save(); return value
  }

  @Remote('recipes')
  async recipes(): Promise<readonly RecipeRecord[]> { await this.ready; return structuredClone(this.state.recipes) }

  @Remote('renameRecipe')
  async renameRecipe(request: RenameRecipeRequest): Promise<RecipeRecord> {
    await this.ready; const recipe = this.state.recipes.find(item => item.id === request.recipeId)
    if (recipe === undefined) throw new Error(`recipe not found: ${request.recipeId}`)
    const next = { ...recipe, ...(request.name === undefined ? {} : { name: text(request.name, 'name') }), ...(request.description === undefined ? {} : { description: request.description }), updatedAt: now() }
    this.state.recipes = this.state.recipes.map(item => item.id === recipe.id ? next : item); await this.save(); return next
  }

  @Remote('deleteRecipe')
  async deleteRecipe(request: { readonly recipeId: string }): Promise<{ deleted: boolean }> {
    await this.ready; const before = this.state.recipes.length; this.state.recipes = this.state.recipes.filter(item => item.id !== request.recipeId); await this.save(); return { deleted: this.state.recipes.length !== before }
  }

  @Remote('exportRecipe')
  async exportRecipe(request: { readonly recipeId: string }): Promise<string> {
    await this.ready; const recipe = this.state.recipes.find(item => item.id === request.recipeId); if (recipe === undefined) throw new Error('recipe not found'); return JSON.stringify(recipe, null, 2)
  }

  @Remote('importRecipe')
  async importRecipe(request: { readonly json: string }): Promise<RecipeRecord> {
    await this.ready; const parsed = validatedRecipe(JSON.parse(request.json))
    const recipe: RecipeRecord = { ...parsed, id: `recipe-${Date.now().toString(36)}-${randomUUID().slice(0, 8)}`, createdAt: now(), updatedAt: now() }
    this.state.recipes.push(recipe); await this.save(); return recipe
  }

  @Remote('runRecipe')
  async runRecipe(request: RunRecipeRequest): Promise<Record<string, unknown>> {
    await this.ready; const recipe = validatedRecipe(this.requireRecipe(request.recipeId))
    if (request.use === 'reference') {
      const context = await this.recipeContext(recipe.id, 'reference')
      if (request.projectId !== undefined) {
        const project = this.requireProject(request.projectId)
        const agent = await this.resolveAgent(project.sessionId)
        agent.followup(createUserMessage({ content: [{ type: 'text', text: `${request.prompt ?? 'Use this recipe as reference for the next project round.'}${context}` }], source: { kind: 'user' } }))
      }
      return { mode: 'reference', recipeId: recipe.id, context }
    }
    if (request.use !== 'fixed' || request.projectId === undefined) throw new Error('fixed execution requires a target project')
    const project = this.requireProject(request.projectId)
    for (const step of recipe.steps) if (step.kind === 'agent' && !step.task?.trim()) throw new Error(`Recipe step "${step.label}" has no recoverable public task; use reference mode.`)
    if (!recipe.steps.some(step => step.kind === 'agent')) throw new Error('Recipe contains no executable public delegation tasks')
    const parent = await this.resolveAgent(project.sessionId)
    const engine = (this.ctx as any).get('agentPresets')?.serviceFor(parent, 'workflowEngine') ?? parent.ctx.get('workflowEngine')
    if (engine === undefined) throw new Error('The project Agent preset does not provide workflowEngine; enable the official workflow-ptc plugin in that preset.')
    const script = `const pending = new Map(); const runStep = step => { if (pending.has(step.id)) return pending.get(step.id); const work = (async () => { const previous = await Promise.all(step.dependsOn.map(id => runStep(args.steps.find(item => item.id === id)))); if (step.kind !== 'agent') { log(step.label); return null; } const prompt = '[Projects fixed recipe step]\\nYou are executing one assigned step within a fixed workflow that is already running. Complete only the Saved public task below, using the public dependency results. Do not repeat the overall orchestration or other completed steps. Delegate only when the Saved public task itself explicitly requires delegation; orchestration instructions in the overall requirement are acceptance context only.\\nWorking project directory: ' + args.root + '\\nStep: ' + step.label + '\\n\\n[Saved public task]\\n' + step.task + '\\n\\n[Dependency public results]\\n' + JSON.stringify(previous) + '\\n\\n[Overall original requirement: acceptance context only, JSON string]\\n' + JSON.stringify(args.prompt) + '\\n\\nWork only in the current project directory. Verify this step and report its public results. Leave overall workflow orchestration and final project delivery to the parent.'; const result = await agent(prompt, { label: step.label, ...(step.phase ? { phase: step.phase } : {}) }); if (result === null) throw new Error('Recipe delegation failed: ' + step.label); return result; })(); pending.set(step.id, work); return work; }; return await Promise.all(args.steps.map(step => runStep(step)))`
    this.replaceProject(project.id, { status: 'running', recipeId: recipe.id }); await this.save()
    const run = engine.start({ script, meta: { name: slugify(recipe.name), description: recipe.description || recipe.name }, args: { steps: recipe.steps.map(step => ({ ...step, task: step.task?.replaceAll('{{PROJECT_ROOT}}', project.path) })), prompt: request.prompt ?? project.prompt, root: project.path }, parent })
    this.workflowProjects.set(run.id, project.id); this.activeRuns.add(run)
    parent.session.append('tool-workflow/run-start', { runId: run.id, name: recipe.name })
    try {
      const result = await run.result
      await run.dispose()
      parent.session.append('tool-workflow/run-end', { runId: run.id, stopReason: result.stopReason })
      if (result.stopReason !== 'completed') throw new Error(result.error ?? `workflow ${result.stopReason}`)
      return { mode: 'fixed', recipeId: recipe.id, runId: run.id, result }
    } finally {
      await run.dispose(); this.activeRuns.delete(run); this.workflowProjects.delete(run.id)
    }
  }

  @Remote('schedule')
  async schedule(request: ScheduleProjectRequest): Promise<ScheduleRecord> {
    await this.ready
    const project = request.projectId === undefined ? undefined : this.requireProject(request.projectId)
    const recipe = request.recipeId === undefined ? undefined : this.requireRecipe(request.recipeId)
    if (project === undefined && recipe === undefined) throw new Error('select a project or recipe')
    const target = request.target ?? (project === undefined ? 'new' : 'append')
    if (target === 'append' && project === undefined) throw new Error('append mode requires a project')
    const selector = this.scheduleSelector(request)
    const title = (request.title?.trim() || `${project?.name ?? recipe!.name} scheduled run`).slice(0, 120)
    const token = randomUUID()
    const recipeId = recipe?.id ?? project?.recipeId
    if (recipeId !== undefined) this.requireRecipe(recipeId)
    const instruction = request.prompt?.trim() || project?.prompt || `Run recipe ${recipe!.name}.`
    const prompt = target === 'new'
      ? `A Projects schedule is due. Call projects_create with scheduleId ${JSON.stringify(token)} exactly once. This tool creates the project and forwards its saved requirement. Do not perform the project in this scheduler Session.\n[projects-schedule:${token}]`
      : recipeId === undefined ? instruction
        : `A Projects recipe schedule is due for this project. Call projects_run_recipe with scheduleId ${JSON.stringify(token)} exactly once. The tool loads the saved requirement and executes the saved recipe in its configured fixed/reference mode. Do not substitute another workflow or resend this reminder as a requirement. After a fixed execution, review its returned public results, verify the files with ui_check where applicable, present the files, and update projects_deliver. In reference mode the tool queues the saved requirement with recipe context for the next round.\n[projects-schedule:${token}]`
    const sessionId = target === 'new' ? await this.schedulerSession() : project!.sessionId
    const schedule = await (this.ctx as any).schedule.create(sessionId, { title, prompt, ...selector })
    const record: ScheduleRecord = { id: schedule.id, ...(project === undefined ? {} : { projectId: project.id }), ...(recipeId === undefined ? {} : { recipeId }), sessionId, target, kind: selectorKind(selector), title, prompt: instruction, selector: { ...selector, dispatchToken: token }, recipeUse: request.recipeUse ?? 'fixed', createdAt: now(), nextRun: schedule.scheduledAt, status: 'active' }
    this.state.schedules.push(record); await this.save(); return record
  }

  @Remote('schedules')
  async schedules(): Promise<readonly ScheduleRecord[]> {
    await this.ready
    const catalog = await (this.ctx as any).schedule.catalog()
    return this.state.schedules.map(record => {
      const current = catalog.find((item: any) => item.id === record.id)
      return structuredClone({ ...record, ...(current === undefined ? { status: 'inactive' as const } : { nextRun: current.scheduledAt, status: current.status }) })
    })
  }

  @Remote('deleteSchedule')
  async deleteSchedule(request: { readonly scheduleId: string }): Promise<{ deleted: boolean }> {
    await this.ready; const record = this.state.schedules.find(item => item.id === request.scheduleId); if (record === undefined) return { deleted: false }
    await (this.ctx as any).schedule.delete({ sessionId: record.sessionId, id: record.id }); this.state.schedules = this.state.schedules.filter(item => item.id !== record.id); await this.save(); return { deleted: true }
  }

  @Remote('uiCheck')
  async uiCheck(request: UiCheckRequest, signal?: AbortSignal): Promise<unknown> {
    await this.ready
    const root = await realpath(resolve(text(request.root, 'root')))
    const allowedRoot = await realpath(this.config.projectsRoot)
    if (!inside(allowedRoot, root)) throw new Error('ui_check root must be inside the configured Projects directory')
    const steps = typeof request.steps === 'string' ? JSON.parse(request.steps) : structuredClone(request.steps)
    if (!Array.isArray(steps) || steps.length > 500) throw new Error('steps must be a JSON array with at most 500 entries')
    if (JSON.stringify(steps).length > 1000000) throw new Error('steps exceed the 1 MB limit')
    const localPath = async (value: string | undefined): Promise<string | undefined> => {
      if (value === undefined) return undefined
      const path = resolve(root, text(value, 'output path'))
      if (!inside(root, path)) throw new Error('ui_check output paths must stay inside the project')
      const parent = await realpath(dirname(path))
      if (!inside(root, parent)) throw new Error('ui_check output path resolves outside the project')
      return path
    }
    const out = await localPath(request.out), shot = await localPath(request.shot)
    for (const step of steps) {
      if (step === null || typeof step !== 'object' || typeof step.do !== 'string') throw new Error('each step needs a do action')
      if (step.do === 'shot') step.path = await localPath(text(step.path, 'screenshot path'))
      if (step.do === 'wait' && (!Number.isFinite(step.ms ?? 300) || (step.ms ?? 300) < 0 || (step.ms ?? 300) > 30000)) throw new Error('wait steps must be between 0 and 30000 ms')
    }
    if (request.page !== undefined && (isAbsolute(request.page) || !inside(root, resolve(root, request.page)) || /[?#]/.test(request.page))) throw new Error('page must be a local relative page path')
    const stepsPath = join(root, `.dsh-ui-check-${randomUUID()}.json`)
    await writeFile(stepsPath, JSON.stringify(steps), 'utf8')
    try {
      const result: any = await this.runUiCheck(root, stepsPath, { ...request, out, shot }, signal)
      const project = this.state.projects.find(item => resolve(item.path).toLowerCase() === root.toLowerCase())
      if (project !== undefined) {
        const current = this.requireProject(project.id)
        const card = deliveryCard({ projectId: project.id, name: project.name, path: project.path, files: current.board.deliverables, summary: current.delivery?.summary, humanChecks: current.delivery?.humanChecks, selfTest: { passed: result.pass === true, command: 'ui_check', output: result } })
        this.replaceProject(project.id, { delivery: card }); await this.save()
      }
      return result
    } finally { await rm(stepsPath, { force: true }) }
  }

  private installAgentTools(agent: any): void {
    if (agent === undefined || this.installedAgents.has(agent)) return
    this.installedAgents.add(agent)
    const service = this
    // Agent-scoped tools become available only after its preset is mounted.
    // The Projects fiber also owns the injection so unloading revokes them.
    this.ctx.effect(() => {
      const fiber = agent.ctx.inject(['tools'], (toolCtx: any) => {
        const output = { schema: { type: 'object' as const, additionalProperties: true }, render: (_args: any, value: unknown) => [{ type: 'text' as const, text: JSON.stringify(value) }] }
        toolCtx.tools.register(defineTool({
          name: 'ui_check', description: 'Run hidden local Edge/Chrome UI checks. steps is a JSON array of click/type/key/expect/eval/wait/reload/shot actions. No browser download.',
          timeoutMs: service.config.uiCheckTimeoutMs + 10000,
          parameters: { root: { type: 'string', required: true, description: 'Project directory.' }, steps: { type: 'string', required: true, description: 'JSON steps array; expect uses js and equals/contains/matches/truthy.' }, page: { type: 'string', description: 'Relative page, usually index.html.' }, out: { type: 'string', description: 'Optional result path inside project.' }, shot: { type: 'string', description: 'Optional screenshot path inside project.' } }, output,
          async execute(args: any, exec: any) { return service.uiCheck(args, exec.signal) },
        }))
        toolCtx.tools.register(defineTool({
          name: 'projects_deliver', description: 'Publish the current Projects project delivery card after presenting files with the official present tool. Include a concrete summary, honest test result, and remaining human checks.',
          parameters: { summary: { type: 'string', required: true, description: 'What was implemented and how to open it.' }, selfTest: { type: 'object', additionalProperties: true, properties: { passed: { type: 'boolean', required: true }, command: { type: 'string' }, output: { type: 'json' } }, description: 'Actual self-test result.' }, humanChecks: { type: 'array', items: { type: 'string' }, description: 'Checks requiring a person; empty when none.' } }, output,
          async execute(args: any, exec: any) {
            await service.ready
            const project = service.projectForSession(exec.agent?.session)
            if (project === undefined) throw new Error('projects_deliver requires a project Session')
            return service.deliver({ projectId: project.id, ...args, selfTest: args.selfTest ?? service.requireProject(project.id).delivery?.selfTest })
          },
        }))
        toolCtx.tools.register(defineTool({
          name: 'projects_create', description: 'Create a Projects workspace and main Session. In the Projects scheduler Session, pass the reminder scheduleId to dispatch its saved requirement exactly once.',
          parameters: { name: { type: 'string' }, prompt: { type: 'string' }, recipeId: { type: 'string' }, recipeUse: { type: 'string', enum: ['reference', 'fixed'] }, scheduleId: { type: 'string' } }, output,
          async execute(args: any, exec: any) {
            if (args.scheduleId !== undefined) return service.dispatchScheduledProject(args.scheduleId, exec.agent)
            return service.create(args)
          },
        }))
        toolCtx.tools.register(defineTool({
          name: 'projects_run_recipe', description: 'Dispatch a due Projects recipe schedule in its authorized project Session. The saved requirement and configured fixed/reference mode are loaded from the schedule. Fixed execution returns public workflow results; reference mode queues the next project round.',
          parameters: { scheduleId: { type: 'string', required: true, description: 'The scheduleId token from this due Projects reminder.' } }, output,
          async execute(args: any, exec: any) { return service.dispatchScheduledProject(args.scheduleId, exec.agent) },
        }))
      })
      return () => fiber.dispose()
    }, `projects: tools for ${agent.id}`)
  }

  private async runUiCheck(root: string, stepsPath: string, request: UiCheckRequest, signal?: AbortSignal): Promise<unknown> {
    const args = [this.config.uiCheckCommand, '--root', root, '--steps', stepsPath, ...(request.page === undefined ? [] : ['--page', request.page]), ...(request.out === undefined ? [] : ['--out', request.out]), ...(request.shot === undefined ? [] : ['--shot', request.shot])]
    const controller = new AbortController(); this.uiChecks.add(controller)
    const onAbort = () => controller.abort(signal?.reason ?? new Error('ui_check cancelled'))
    signal?.addEventListener('abort', onAbort, { once: true })
    if (signal?.aborted) onAbort()
    const timeout = setTimeout(() => controller.abort(new Error('ui_check timed out')), this.config.uiCheckTimeoutMs)
    try {
    return await new Promise((resolveResult, reject) => {
      const child = spawn(process.execPath, args, { cwd: root, windowsHide: true, env: { ...process.env, NO_PROXY: '*' }, stdio: ['ignore', 'pipe', 'pipe'] })
      const abort = () => {
        if (process.platform === 'win32' && child.pid !== undefined) {
          const killer = spawn('taskkill', ['/PID', String(child.pid), '/T', '/F'], { windowsHide: true, stdio: 'ignore' }); killer.on('error', () => child.kill())
        } else child.kill('SIGTERM')
      }
      controller.signal.addEventListener('abort', abort, { once: true })
      if (controller.signal.aborted) abort()
      let output = '', error = ''; child.stdout.on('data', chunk => { output += String(chunk) }); child.stderr.on('data', chunk => { error += String(chunk) })
      child.once('error', error => { controller.signal.removeEventListener('abort', abort); reject(error) }); child.once('close', code => {
        controller.signal.removeEventListener('abort', abort)
        if (controller.signal.aborted) { reject(controller.signal.reason); return }
        try {
          const parsed = JSON.parse(output.trim() || '{}')
          if (code !== 0 && code !== 1) reject(new Error(error || JSON.stringify(parsed)))
          else resolveResult(parsed)
        } catch (parseError) { reject(new Error(error || `ui_check returned invalid JSON: ${String(parseError)}`)) }
      })
    })
    } finally { clearTimeout(timeout); signal?.removeEventListener('abort', onAbort); this.uiChecks.delete(controller) }
  }

  private installWorkflowEvents(): void {
    const append = (info: any, type: string, data: any) => {
      const id = this.workflowProjects.get(info.id)
      const project = id === undefined ? undefined : this.state.projects.find(item => item.id === id)
      const parent = project === undefined ? undefined : (this.ctx as any).agents.get(project.sessionId)
      if (parent !== undefined) parent.session.append(type, { runId: info.id, ...data })
    }
    this.ctx.on('workflow/agent-start', (info: any, agent: any) => append(info, 'tool-workflow/agent-start', { seq: agent.seq, label: agent.label, ...(agent.phase === undefined ? {} : { phase: agent.phase }), childId: agent.childId }), { global: true })
    this.ctx.on('workflow/agent-end', (info: any, agent: any) => append(info, 'tool-workflow/agent-end', { seq: agent.seq, outcome: agent.outcome }), { global: true })
  }

  private async schedulerSession(): Promise<string> {
    await this.ready
    if (this.schedulerReady !== undefined) return this.schedulerReady
    this.schedulerReady = (async () => {
      if (this.state.schedulerSessionId !== undefined) { await this.resolveAgent(this.state.schedulerSessionId); return this.state.schedulerSessionId }
      await mkdir(this.config.projectsRoot, { recursive: true })
      const created = await (this.ctx as any).sessionController.create({ cwd: this.config.projectsRoot, ...(this.config.leaderPreset === null ? {} : { agentPreset: this.config.leaderPreset }) })
      this.state.schedulerSessionId = created.sessionId; await this.save()
      await (this.ctx as any).sessionController.rename({ sessionId: created.sessionId, title: this.config.scheduleSessionTitle })
      return created.sessionId
    })()
    try { return await this.schedulerReady } catch (error) { this.schedulerReady = undefined; throw error }
  }

  private async dispatchScheduledProject(token: string, agent: any): Promise<ProjectRecord & { readonly execution?: Record<string, unknown> }> {
    const work = this.dispatchTail.then(async () => {
      await this.ready
      const record = this.state.schedules.find(item => item.selector.dispatchToken === token)
      if (record === undefined) throw new Error('Unknown or deleted Projects schedule')
      if (agent?.id !== record.sessionId) throw new Error('Scheduled dispatch requires the schedule target Session')
      if (record.target === 'new' && agent.id !== this.state.schedulerSessionId) throw new Error('New project dispatch requires the Projects scheduler Session')
      const snapshot = await (this.ctx as any).sessionController.inspect(agent.id)
      const messages = snapshot.events.filter((item: any) => item.type === 'user/message' && item.data?.source?.kind === 'schedule' && publicText(item.data?.content).includes(`[projects-schedule:${token}]`))
      const message = messages.at(-1)
      if (message === undefined || typeof message.data?.id !== 'string') throw new Error('No due official schedule message authorizes this dispatch')
      if (record.lastMessageId === message.data.id && record.lastProjectId !== undefined) return publicSnapshot(this.requireProject(record.lastProjectId))
      const source = record.projectId === undefined ? undefined : this.requireProject(record.projectId)
      const recipe = record.recipeId === undefined ? undefined : this.requireRecipe(record.recipeId)
      let project: ProjectRecord, execution: Record<string, unknown> | undefined
      if (record.target === 'new') {
        project = await this.create({ name: `${source?.name ?? recipe?.name ?? 'Scheduled project'} ${new Date().toISOString().replace(/[:.]/g, '-')}`, prompt: record.prompt, ...(record.recipeId === undefined ? {} : { recipeId: record.recipeId, recipeUse: record.recipeUse ?? 'fixed' }) })
      } else {
        if (source === undefined || recipe === undefined) throw new Error('Scheduled recipe append requires a project and recipe')
        // Forward the saved requirement, never the reminder containing this tool call.
        execution = await this.runRecipe({ recipeId: recipe.id, use: record.recipeUse ?? 'fixed', projectId: source.id, prompt: record.prompt })
        project = publicSnapshot(this.requireProject(source.id))
      }
      this.state.schedules = this.state.schedules.map(item => item.id === record.id ? { ...item, lastMessageId: message.data.id, lastProjectId: project.id } : item)
      await this.save(); return { ...project, ...(execution === undefined ? {} : { execution }) }
    })
    this.dispatchTail = work.catch(() => undefined)
    return work
  }

  private projectForSession(session: any): ProjectRecord | undefined {
    const visited = new Set<string>()
    while (session?.header?.id !== undefined && !visited.has(session.header.id)) {
      visited.add(session.header.id)
      const project = this.state.projects.find(item => item.sessionId === session.header.id)
      if (project !== undefined) return project
      session = (this.ctx as any).agents.get(session.header.parentSession)?.session
    }
    return undefined
  }

  private async resolveAgent(sessionId: string): Promise<any> {
    const result = await (this.ctx as any).sessionController.resolveAgent(sessionId)
    if (result.agent === undefined) throw new Error(`Could not resolve project Session: ${JSON.stringify(result.error)}`)
    this.installAgentTools(result.agent); return result.agent
  }

  private replaceProject(id: string, patch: Partial<ProjectRecord>): void {
    this.state.projects = this.state.projects.map(item => item.id === id ? { ...item, ...patch, updatedAt: now() } : item)
  }

  private async allocateProjectPath(slug: string): Promise<string> {
    await mkdir(this.config.projectsRoot, { recursive: true })
    for (let index = 0; index < 10000; index++) {
      const path = join(this.config.projectsRoot, index === 0 ? slug : `${slug}-${index + 1}`)
      try { await mkdir(path); return path } catch (error: any) { if (error?.code !== 'EEXIST') throw error }
    }
    throw new Error('Could not allocate a unique project directory')
  }

  private background(task: Promise<unknown>, projectId?: string): void {
    const owned = task.catch(async error => {
      this.ctx.logger.warn(`projects: background operation failed: ${String(error)}`)
      if (projectId !== undefined) { this.replaceProject(projectId, { status: 'failed', lastError: String(error) }); await this.save() }
    }).catch(error => this.ctx.logger.warn(`projects: could not save operation failure: ${String(error)}`))
    this.tasks.add(owned); void owned.then(() => this.tasks.delete(owned))
  }

  private openingPrompt(project: ProjectRecord): string {
    return `${project.prompt}\n\n[Projects workspace]\nProject: ${project.name}\nWorking directory: ${project.path}\nWork in this directory. Keep your public plan and todo_write list current. For browser pages, call ui_check with real assertions before delivery. Present the finished files using the official present tool, then call projects_deliver with what you built, how to open it, actual self-test results, and any remaining human checks. Never claim a check that was not run.\n`
  }

  private fixedReviewPrompt(project: ProjectRecord, result: Record<string, unknown>): string {
    return `[Projects fixed workflow: review and delivery]\nThe saved workflow has already executed successfully for this project. This round is for reviewing its output, checking the files, and delivering the result. Do not run workflow again, create another delegation, or repeat completed recipe steps. Any orchestration or delegation instructions quoted in the original requirement below were already handled by the saved workflow; use the requirement only as acceptance context.\n\nProject: ${project.name}\nWorking directory: ${project.path}\n\nReview the public workflow results and inspect the actual files in this directory. Reflect completed work and remaining verification in todo_write. For a browser page, run ui_check with real assertions against the acceptance criteria. If verification finds a defect, make the necessary correction directly and repeat the relevant check. Present the finished files with the official present tool, then call projects_deliver with what was built, how to open it, actual self-test results, and any remaining human checks. Mark the verified todos complete. Report an unresolved failure honestly.\n\n[Original requirement — acceptance context only, JSON string]\n${JSON.stringify(project.prompt)}\n\n[Completed workflow — public results]\n${JSON.stringify(result)}\n\nContinue with file review, verification, and delivery only; the fixed workflow is complete.\n`
  }

  private async recipeContext(id: string, use: RecipeUse): Promise<string> {
    const recipe = this.state.recipes.find(item => item.id === id); if (recipe === undefined) throw new Error(`recipe not found: ${id}`)
    return `\n\n[Projects recipe ${use}]\n${JSON.stringify({ name: recipe.name, steps: recipe.steps })}\nLeader retains final authority; use this only as public workflow context.`
  }
  private requireProject(id: string): ProjectRecord { const project = this.state.projects.find(item => item.id === id); if (project === undefined) throw new Error(`project not found: ${id}`); return project }
  private requireRecipe(id: string): RecipeRecord { const recipe = this.state.recipes.find(item => item.id === id); if (recipe === undefined) throw new Error(`recipe not found: ${id}`); return recipe }
  private scheduleSelector(request: ScheduleProjectRequest): Record<string, unknown> {
    const keys = ['after_seconds', 'every_seconds', 'daily', 'weekly', 'cron'] as const; const selected = keys.filter(key => request[key] !== undefined); if (selected.length !== 1) throw new Error('choose exactly one schedule selector')
    const key = selected[0], value = request[key]
    if (key === 'cron') {
      // DSH's public cron selector uses an explicit IANA zone.  The short UI
      // form accepts a string and expands it before calling the official API.
      if (typeof value === 'string') return { cron: { expression: text(value, 'cron'), time_zone: 'Asia/Taipei' } }
      if (value === null || typeof value !== 'object' || typeof (value as any).expression !== 'string' || typeof (value as any).time_zone !== 'string') throw new Error('cron needs expression and time_zone')
    }
    return { [key]: value }
  }
}

function selectorKind(selector: Record<string, unknown>): ScheduleRecord['kind'] { if ('after_seconds' in selector) return 'after'; if ('every_seconds' in selector) return 'every'; if ('daily' in selector) return 'daily'; if ('weekly' in selector) return 'weekly'; return 'cron' }

export const name = 'dsh-plugin-projects'
export const inject = ProjectsService.inject
export function apply(ctx: Context, config: ProjectsConfig = {}): void { ctx.plugin(ProjectsService, config) }
export default ProjectsService
