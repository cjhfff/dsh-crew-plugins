/** Browser entry for the Projects workspace/sidebar surface. */
import type { Context } from '@deepseek-ai/cordis'
import { registerProjectsUi } from './mount.ts'

export { inject } from './mount.ts'

export function apply(ctx: Context): void {
  registerProjectsUi(ctx)
}
