﻿/** Official browser slots and scoped Remote ownership for Projects. */
import type { Context } from '@deepseek-ai/cordis'
import React from 'react'
import projectsRemote from '../../lib/typert.remote-client.js'
import { ProjectsPage, type ProjectsActions } from './page.tsx'
import { styles } from './styles.ts'

export const inject = ['remote', 'slots', 'uiWorkspace', 'sessions']
const PANEL = 'projects'
function ProjectsIcon({ size = 20 }: { size?: number }): React.ReactElement {
  return React.createElement('svg', { width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 1.7, strokeLinecap: 'round', strokeLinejoin: 'round', 'aria-hidden': true }, React.createElement('path', { d: 'M3 7a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v10H3Z' }), React.createElement('path', { d: 'm8 13 2 2 5-5' }))
}
/** Cordis owns slots, stylesheet, and Remote mount; nothing leaks to globals. */
export function registerProjectsUi(ctx: Context): void {
  ctx.effect(() => {
    const style = document.createElement('style')
    style.dataset.dshPlugin = 'projects'; style.textContent = styles
    document.head.appendChild(style)
    return () => style.remove()
  }, 'projects: page styles')
  ctx.effect(async () => {
    const unmount = await ctx.remote.$mount(projectsRemote)
    // A mounted descriptor provides a separate Cordis service. Reading it
    // through the parent Context is forbidden even when Remote is injected.
    const page = ctx.inject(['remote.projects'], (remoteCtx) => {
      const api = (remoteCtx.remote as any).projects
      const actions: ProjectsActions = {
        async call(method, request) {
          const result = await (request === undefined ? api[method]() : api[method](request))
          if (result && typeof result === 'object' && 'ok' in result) {
            if (!result.ok) throw new Error(result.error?.message ?? result.error?.code ?? '请求失败')
            return result.value
          }
          return result
        },
        openSession: sessionId => remoteCtx.uiWorkspace.openSession(sessionId as any),
      }
      remoteCtx.slots.inject('main', () => remoteCtx.slots.register({ name: 'main', key: PANEL as any, inject: () => actions }, ProjectsPage as any))
      remoteCtx.slots.inject('sidebar.panellist', () => remoteCtx.slots.register({ name: 'sidebar.panellist', id: PANEL as any, order: 15, label: () => '项目与交付' }, ProjectsIcon as any))
    })
    try { await page } catch (error) { await unmount(); throw error }
    return async () => {
      await page.dispose()
      await unmount()
    }
  }, 'projects: remote namespace and page')
}
