import React from 'react'
import type { BoardState, ProjectRecord, RecipeRecord, RecipeUse, ScheduleKind, ScheduleRecord } from '../types.ts'

export interface ProjectsActions {
  call<T = any>(method: string, request?: unknown): Promise<T>
  openSession(sessionId: string): void
}
type Run = (label: string, work: () => Promise<void>) => Promise<void>
type Tab = 'projects' | 'recipes' | 'schedules'
const EMPTY: BoardState = { plan: [], todos: [], deliverables: [], workflow: [] }
const status: Record<string, string> = { running: '进行中', waiting: '等你回答', delivered: '已交付', failed: '遇到问题', pending: '待办', in_progress: '进行中', completed: '已完成', done: '已完成', active: '生效中', inactive: '已结束', expired: '已过期', unknown: '状态未知' }
const dt = (value?: string) => value ? new Date(value).toLocaleString('zh-CN', { hour12: false }) : '—'
const text = (value: any): string => typeof value === 'string' ? value : value == null ? '' : JSON.stringify(value, null, 2)
const title = (item: any): string => typeof item === 'string' ? item : item?.content ?? item?.subject ?? item?.title ?? item?.description ?? item?.text ?? item?.name ?? (typeof item?.active === 'boolean' ? item.active ? '计划模式已开启' : '计划模式已关闭' : item?.mode ? `计划模式：${item.mode}` : text(item))
function Empty({ children }: { children: React.ReactNode }) { return <p className="pr-empty">{children}</p> }
function Field({ label, children }: { label: string; children: React.ReactNode }) { return <label className="pr-field"><span>{label}</span>{children}</label> }
function Badge({ value }: { value: string }) { return <span className={`pr-badge pr-${value}`}>{status[value] ?? value}</span> }
function Download({ name, content }: { name: string; content: string }) {
  const [url, setUrl] = React.useState('')
  React.useEffect(() => { const u = URL.createObjectURL(new Blob([content], { type: 'application/json;charset=utf-8' })); setUrl(u); return () => URL.revokeObjectURL(u) }, [content])
  return <a className="pr-button" href={url} download={name}>下载 JSON 文件</a>
}

/** The selected board follows the shared Session store, with the Host catalog as its retained fallback. */
export function ProjectsPage({ call, openSession, useSessions }: ProjectsActions & { useSessions?: (selector: (state: any) => any) => any }): React.ReactElement {
  const [tab, setTab] = React.useState<Tab>('projects'), [projects, setProjects] = React.useState<ProjectRecord[]>([]), [recipes, setRecipes] = React.useState<RecipeRecord[]>([]), [schedules, setSchedules] = React.useState<ScheduleRecord[]>([])
  const [projectId, setProjectId] = React.useState(''), [recipeId, setRecipeId] = React.useState(''), [busy, setBusy] = React.useState(''), [loading, setLoading] = React.useState(true), [error, setError] = React.useState(''), [notice, setNotice] = React.useState('')
  const [createOpen, setCreateOpen] = React.useState(false), [createRecipe, setCreateRecipe] = React.useState({ id: '', use: 'reference' as RecipeUse }), [scheduleOpen, setScheduleOpen] = React.useState(false)
  const mounted = React.useRef(true), working = React.useRef(false), reading = React.useRef<Promise<void> | undefined>(undefined)
  const refresh = React.useCallback((silent = false): Promise<void> => {
    if (reading.current) return reading.current
    const request = (async () => {
      if (!silent && mounted.current) setLoading(true)
      try {
        const rows = await Promise.all([call<ProjectRecord[]>('list'), call<RecipeRecord[]>('recipes'), call<ScheduleRecord[]>('schedules')])
        if (!mounted.current) return
        setProjects(rows[0]); setRecipes(rows[1]); setSchedules(rows[2])
        setProjectId(id => rows[0].some(p => p.id === id) ? id : rows[0][0]?.id ?? '')
        setRecipeId(id => rows[1].some(p => p.id === id) ? id : rows[1][0]?.id ?? '')
      } catch (e) { if (mounted.current) setError(e instanceof Error ? e.message : String(e)) }
      finally { if (mounted.current) setLoading(false) }
    })()
    reading.current = request
    void request.finally(() => { if (reading.current === request) reading.current = undefined })
    return request
  }, [call])
  React.useEffect(() => {
    mounted.current = true; void refresh()
    const timer = window.setInterval(() => { if (!document.hidden && !working.current) void refresh(true) }, 5000)
    return () => { mounted.current = false; window.clearInterval(timer) }
  }, [refresh])
  const changed = async () => { if (reading.current) await reading.current; await refresh(true) }
  const run: Run = async (label, work) => {
    if (working.current) return
    working.current = true; setBusy(label); setError(''); setNotice('')
    try { await work() } catch (e) { if (mounted.current) setError(e instanceof Error ? e.message : String(e)) }
    finally { working.current = false; if (mounted.current) setBusy('') }
  }
  const selected = projects.find(p => p.id === projectId)
  const shared = useSessions?.(state => selected ? state.projectionsBySession?.[selected.sessionId]?.values.projectsBoard : undefined) as BoardState | undefined
  const project = selected ? { ...selected, board: shared ?? selected.board ?? EMPTY } : undefined
  const newFromRecipe = (recipe: RecipeRecord, use: RecipeUse) => { setCreateRecipe({ id: recipe.id, use }); setCreateOpen(true); setTab('projects') }
  return <section className="dsh-projects" aria-label="项目与交付" data-testid="projects-view"><div className="pr-content">
    <header className="pr-heading"><div><div className="pr-eyebrow">PROJECTS</div><h1>项目与交付</h1><p>从一句需求开始，把计划、成果和下一次运行放在一起。</p></div><div className="pr-actions"><button disabled={!!busy || loading} onClick={() => { setError(''); void refresh() }}>刷新</button><button className="pr-primary" onClick={() => { setTab('projects'); setCreateOpen(true) }}>＋ 新建项目</button></div></header>
    <nav className="pr-tabs" aria-label="项目功能">{([['projects', '项目', projects.length], ['recipes', '配方', recipes.length], ['schedules', '定时', schedules.length]] as const).map(([id, label, count]) => <button key={id} data-projects-tab={id} className={tab === id ? 'is-active' : ''} aria-current={tab === id ? 'page' : undefined} onClick={() => setTab(id)}>{label}<span>{count}</span></button>)}</nav>
    <div aria-live="polite">{error && <div className="pr-message pr-error" role="alert">{error}<button aria-label="关闭错误" onClick={() => setError('')}>×</button></div>}{notice && <div className="pr-message pr-success" role="status">{notice}<button aria-label="关闭提示" onClick={() => setNotice('')}>×</button></div>}{busy && <div className="pr-progress" role="status">{busy}…</div>}</div>
    {loading && !projects.length && !recipes.length && !schedules.length && <Empty>正在加载项目…</Empty>}
    {tab === 'projects' && <>
      {createOpen && <CreateProject key={`${createRecipe.id}:${createRecipe.use}`} recipes={recipes} initialRecipe={createRecipe} busy={!!busy} onClose={() => { setCreateOpen(false); setCreateRecipe({ id: '', use: 'reference' }) }} onSubmit={request => run('正在创建项目', async () => { const created = await call<ProjectRecord>('create', request); await changed(); setProjectId(created.id); setCreateOpen(false); setCreateRecipe({ id: '', use: 'reference' }); setNotice(`已创建“${created.name}”，主会话已收到需求。`) })}/>}
      <div className="pr-project-layout"><aside className="pr-project-list" aria-label="项目列表"><div className="pr-section-title"><h2>所有项目</h2><span>{projects.length}</span></div>{projects.length ? projects.map(item => <button key={item.id} data-project-id={item.id} className={`pr-project-row ${item.id === projectId ? 'is-active' : ''}`} onClick={() => { setProjectId(item.id); setScheduleOpen(false) }}><div><strong>{item.name}</strong><Badge value={item.status}/></div><p>{item.delivery?.summary ?? item.prompt}</p><small>{dt(item.updatedAt)} · {item.board?.deliverables?.length ?? 0} 个交付物</small></button>) : <Empty>创建第一个项目，开始执行需求。</Empty>}</aside>
        {project ? <div className="pr-project-detail" data-testid="project-detail"><header className="pr-detail-heading"><div><div className="pr-row"><h2>{project.name}</h2><Badge value={project.status}/></div><code>{project.path}</code><small>最近更新 {dt(project.updatedAt)}</small></div><button onClick={() => void run('正在打开会话', async () => { openSession(project.sessionId) })}>打开主会话 ↗</button></header>
          {project.lastError && <div className="pr-message pr-error">{project.lastError}</div>}<div className="pr-request"><span>项目需求</span><p>{project.prompt}</p></div>
          <div className="pr-actions"><button disabled={!!busy} onClick={() => void run('正在保存配方', async () => { const recipe = await call<RecipeRecord>('saveRecipe', { projectId: project.id }); await changed(); setRecipeId(recipe.id); setTab('recipes'); setNotice('已从公开工作流事件保存配方。') })}>保存为配方</button><button aria-expanded={scheduleOpen} onClick={() => setScheduleOpen(v => !v)}>定时运行</button></div>
          {scheduleOpen && <ScheduleForm key={project.id} projects={projects} recipes={recipes} initialProject={project.id} busy={!!busy} onClose={() => setScheduleOpen(false)} onSubmit={request => run('正在创建定时', async () => { await call('schedule', request); await changed(); setScheduleOpen(false); setNotice('定时任务已创建。') })}/>}
          <Board board={project.board}/><Delivery project={project} busy={!!busy} onSave={request => run('正在保存交付卡片', async () => { await call('deliver', { projectId: project.id, ...request }); await changed(); setNotice('交付卡片已保存。') })}/>
          <section className="pr-card"><div className="pr-section-title"><h3>运行记录</h3><span>{project.board.workflow.length} 条</span></div>{project.board.workflow.length ? <ol className="pr-timeline">{project.board.workflow.slice(-30).map((event, i) => <li key={`${event.runId}:${i}`}><span className="pr-timeline-dot"/><div><strong>{event.label ?? event.phase ?? event.type}</strong><small>{status[event.status ?? ''] ?? event.status}{event.at ? ` · ${dt(event.at)}` : ''}</small>{event.detail && <p>{event.detail}</p>}</div></li>)}</ol> : <Empty>执行时的公开委派与工作流事件会显示在这里。</Empty>}</section>
        </div> : <div className="pr-card pr-detail-empty"><Empty>选择项目查看计划、待办和交付卡片。</Empty></div>}
      </div>
    </>}
    {tab === 'recipes' && <Recipes recipes={recipes} selectedId={recipeId} onSelect={setRecipeId} call={call} run={run} busy={!!busy} changed={changed} notice={setNotice} onNew={newFromRecipe} onSchedule={recipe => { setRecipeId(recipe.id); setScheduleOpen(true); setTab('schedules') }}/>}
    {tab === 'schedules' && <Schedules projects={projects} recipes={recipes} schedules={schedules} showForm={scheduleOpen} initialRecipe={recipeId} onToggle={() => setScheduleOpen(v => !v)} call={call} run={run} busy={!!busy} changed={changed} notice={setNotice}/>}
  </div></section>
}

function CreateProject({ recipes, initialRecipe, busy, onClose, onSubmit }: { recipes: RecipeRecord[]; initialRecipe: { id: string; use: RecipeUse }; busy: boolean; onClose(): void; onSubmit(value: unknown): Promise<void> }) {
  const [name, setName] = React.useState(''), [prompt, setPrompt] = React.useState(''), [recipeId, setRecipeId] = React.useState(initialRecipe.id), [use, setUse] = React.useState(initialRecipe.use)
  return <form className="pr-card pr-create" aria-label="新建项目" onSubmit={e => { e.preventDefault(); void onSubmit({ name: name.trim(), prompt: prompt.trim(), ...(recipeId ? { recipeId, recipeUse: use } : {}) }) }}><div className="pr-section-title"><h2>一句需求开项目</h2><button type="button" onClick={onClose} aria-label="关闭新建项目">×</button></div>
    <div className="pr-form-grid"><Field label="项目名"><input required autoFocus maxLength={160} value={name} onChange={e => setName(e.target.value)} placeholder="例如：每秒更新的时钟"/></Field><Field label="使用配方"><select value={recipeId} onChange={e => setRecipeId(e.target.value)}><option value="">从需求开始</option>{recipes.map(r => <option key={r.id} value={r.id}>{r.name}</option>)}</select></Field></div>
    <Field label="一句需求"><textarea required rows={3} value={prompt} onChange={e => setPrompt(e.target.value)} placeholder="告诉 Leader 想做什么、怎样算完成…"/></Field>
    {recipeId && <div className="pr-choice"><label><input type="radio" checked={use === 'reference'} onChange={() => setUse('reference')}/>作为参考 <small>由 Leader 自主安排</small></label><label><input type="radio" checked={use === 'fixed'} onChange={() => setUse('fixed')}/>固定执行 <small>按配方顺序与依赖运行</small></label></div>}
    <div className="pr-form-footer"><small>创建项目目录、工作区和主会话，并发送这条需求。</small><button type="submit" className="pr-primary" disabled={busy || !name.trim() || !prompt.trim()}>创建并开始</button></div>
  </form>
}
function Board({ board }: { board: BoardState }) {
  const pending = board.todos.filter((v: any) => !['completed', 'done', 'deleted'].includes(v?.status)), done = board.todos.filter((v: any) => ['completed', 'done'].includes(v?.status))
  return <section className="pr-card" data-testid="project-board"><div className="pr-section-title"><h3>项目看板</h3><span>{done.length}/{board.todos.length} 已完成</span></div><div className="pr-board">{[['计划', board.plan], ['待办 / 进行中', pending], ['已完成', done]].map(([heading, rows], col) => <div className="pr-board-column" key={col}><h4>{heading as string}<span>{(rows as any[]).length}</span></h4>{(rows as any[]).length ? (rows as any[]).map((item, i) => <div className={`pr-task ${col === 2 ? 'pr-task-done' : ''}`} key={item?.id ?? i}>{item?.status && <small>{status[item.status] ?? item.status}</small>}<p>{col === 2 && '✓ '}{title(item)}</p>{item?.plan && <p>{text(item.plan)}</p>}{item?.file && <code>{item.file}</code>}</div>) : <Empty>{col === 0 ? '还没有计划' : col === 1 ? '没有待办事项' : '完成的事项会归入这里'}</Empty>}</div>)}</div></section>
}
function Delivery({ project, busy, onSave }: { project: ProjectRecord; busy: boolean; onSave(value: Record<string, unknown>): Promise<void> }) {
  const [editing, setEditing] = React.useState(false), [summary, setSummary] = React.useState(''), [command, setCommand] = React.useState(''), [output, setOutput] = React.useState(''), [passed, setPassed] = React.useState(false), [human, setHuman] = React.useState('')
  const card = project.delivery, files = card?.files ?? project.board.deliverables
  React.useEffect(() => { setEditing(false); setSummary(card?.summary ?? ''); setCommand(card?.selfTest.command ?? ''); setOutput(text(card?.selfTest.output)); setPassed(card?.selfTest.passed ?? false); setHuman(card?.humanChecks.join('\n') ?? '') }, [project.id, card?.createdAt])
  return <section className="pr-card pr-delivery" data-testid="delivery-card"><div className="pr-section-title"><h3>交付卡片</h3><button onClick={() => setEditing(v => !v)} aria-expanded={editing}>{card ? '编辑交付' : '生成交付卡片'}</button></div>
    {card ? <><h4>{card.title}</h4><p className="pr-delivery-summary">{card.summary}</p><div className="pr-delivery-facts"><div><span>怎么打开</span><code>{card.openPath}</code></div><div><span>自测结果</span><strong className={card.selfTest.passed ? 'pr-test-pass' : 'pr-test-pending'}>{card.selfTest.passed ? '✓ 已通过' : '待确认'}</strong>{card.selfTest.command && <code>{card.selfTest.command}</code>}</div></div>{card.selfTest.output != null && <details><summary>查看自测输出</summary><pre>{text(card.selfTest.output)}</pre></details>}<div className="pr-human-checks"><h4>需要人工确认</h4>{card.humanChecks.length ? <ul>{card.humanChecks.map((check, i) => <li key={i}>{check}</li>)}</ul> : <p>没有额外的人工确认项。</p>}</div></> : <Empty>完成后整理做了什么、怎么打开、自测结果和人工确认项。</Empty>}
    {!!files.length && <div className="pr-files"><h4>交付物 · {files.length}</h4>{files.map((file, i) => <div key={`${file.path}:${i}`}><code>{file.path}</code>{file.description && <span>{file.description}</span>}</div>)}</div>}
    {editing && <form className="pr-delivery-form" onSubmit={e => { e.preventDefault(); void onSave({ summary: summary.trim(), selfTest: { passed, ...(command.trim() ? { command: command.trim() } : {}), ...(output.trim() ? { output: output.trim() } : {}) }, humanChecks: human.split('\n').map(v => v.trim()).filter(Boolean) }) }}><Field label="做了什么"><textarea rows={3} required value={summary} onChange={e => setSummary(e.target.value)}/></Field><div className="pr-form-grid"><Field label="自测命令"><input value={command} onChange={e => setCommand(e.target.value)} placeholder="例如：node --test"/></Field><label className="pr-check"><input type="checkbox" checked={passed} onChange={e => setPassed(e.target.checked)}/>自测已通过</label></div><Field label="自测结果"><textarea rows={2} value={output} onChange={e => setOutput(e.target.value)} placeholder="记录实际测试输出"/></Field><Field label="需要人工确认（每行一项）"><textarea rows={2} value={human} onChange={e => setHuman(e.target.value)}/></Field><div className="pr-form-footer"><button type="button" onClick={() => setEditing(false)}>取消</button><button className="pr-primary" type="submit" disabled={busy || !summary.trim()}>保存交付卡片</button></div></form>}
  </section>
}

function Recipes({ recipes, selectedId, onSelect, call, run, busy, changed, notice, onNew, onSchedule }: { recipes: RecipeRecord[]; selectedId: string; onSelect(id: string): void; call: ProjectsActions['call']; run: Run; busy: boolean; changed(): Promise<void>; notice(value: string): void; onNew(recipe: RecipeRecord, use: RecipeUse): void; onSchedule(recipe: RecipeRecord): void }) {
  const [importing, setImporting] = React.useState(false), [json, setJson] = React.useState(''), [name, setName] = React.useState(''), [description, setDescription] = React.useState(''), [editing, setEditing] = React.useState(false), [confirm, setConfirm] = React.useState(''), [exported, setExported] = React.useState<string | undefined>()
  const recipe = recipes.find(r => r.id === selectedId)
  React.useEffect(() => { setName(recipe?.name ?? ''); setDescription(recipe?.description ?? ''); setEditing(false); setConfirm(''); setExported(undefined) }, [selectedId, recipe?.updatedAt])
  return <section><div className="pr-section-title pr-view-heading"><div><h2>工作流配方</h2><p>保存实际执行步骤，在下一次项目中复用。</p></div><button onClick={() => setImporting(v => !v)}>导入配方</button></div>
    {importing && <form className="pr-card pr-create" onSubmit={e => { e.preventDefault(); void run('正在导入配方', async () => { const r = await call<RecipeRecord>('importRecipe', { json }); await changed(); onSelect(r.id); setImporting(false); setJson(''); notice('配方已导入。') }) }}><Field label="选择 JSON 文件"><input type="file" accept=".json,application/json" onChange={e => { const file = e.target.files?.[0]; if (file) void run('正在读取配方', async () => { setJson(await file.text()) }) }}/></Field><Field label="或粘贴配方 JSON"><textarea rows={5} required value={json} onChange={e => setJson(e.target.value)}/></Field><div className="pr-form-footer"><button type="button" onClick={() => setImporting(false)}>取消</button><button className="pr-primary" type="submit" disabled={busy || !json.trim()}>导入</button></div></form>}
    <div className="pr-library-layout"><aside className="pr-project-list" aria-label="配方列表">{recipes.length ? recipes.map(r => <button key={r.id} className={`pr-project-row ${r.id === selectedId ? 'is-active' : ''}`} onClick={() => onSelect(r.id)}><strong>{r.name}</strong><p>{r.description}</p><small>{r.steps.length} 个步骤 · {dt(r.updatedAt)}</small></button>) : <Empty>从已完成的项目保存配方，或导入 JSON 文件。</Empty>}</aside>
      {recipe ? <article className="pr-card pr-recipe-detail" data-testid="recipe-detail"><div className="pr-section-title"><h3>{recipe.name}</h3><button onClick={() => setEditing(v => !v)}>重命名 / 描述</button></div><p>{recipe.description}</p>
        {editing && <form onSubmit={e => { e.preventDefault(); void run('正在保存配方', async () => { await call('renameRecipe', { recipeId: recipe.id, name: name.trim(), description }); await changed(); setEditing(false); notice('配方已更新。') }) }}><Field label="配方名"><input required value={name} onChange={e => setName(e.target.value)}/></Field><Field label="描述"><textarea rows={2} value={description} onChange={e => setDescription(e.target.value)}/></Field><div className="pr-form-footer"><button type="button" onClick={() => setEditing(false)}>取消</button><button className="pr-primary" type="submit" disabled={busy || !name.trim()}>保存</button></div></form>}
        <div className="pr-actions pr-recipe-actions"><button className="pr-primary" onClick={() => onNew(recipe, 'reference')}>作为参考开项目</button><button onClick={() => onNew(recipe, 'fixed')}>固定执行开项目</button><button onClick={() => onSchedule(recipe)}>定时运行</button><button disabled={busy} onClick={() => void run('正在导出配方', async () => { setExported(await call<string>('exportRecipe', { recipeId: recipe.id })) })}>导出</button><button className="pr-danger" onClick={() => setConfirm(recipe.id)}>删除</button></div>
        {exported && <div className="pr-message"><Download name={`${recipe.name.replace(/[<>:"/\\|?*]/g, '-')}.json`} content={exported}/></div>}
        {confirm === recipe.id && <div className="pr-message pr-warning"><span>删除“{recipe.name}”？已创建的项目仍会保留。</span><div className="pr-actions"><button onClick={() => setConfirm('')}>取消</button><button className="pr-danger" disabled={busy} onClick={() => void run('正在删除配方', async () => { await call('deleteRecipe', { recipeId: recipe.id }); await changed(); setConfirm(''); notice('配方已删除。') })}>确认删除</button></div></div>}
        <h4>步骤与依赖</h4>{recipe.steps.length ? <ol className="pr-recipe-steps">{recipe.steps.map((step, i) => <li key={`${step.id}:${i}`}><span className="pr-step-number">{i + 1}</span><div><strong>{step.label}</strong><small>{({ agent: '委派', workflow: '工作流', phase: '阶段', log: '记录' })[step.kind]}{step.dependsOn.length ? ` · 依赖：${step.dependsOn.map(id => { const n = recipe.steps.findIndex(s => s.id === id); return n < 0 ? id : `步骤 ${n + 1}` }).join('、')}` : ' · 起始步骤'}</small></div></li>)}</ol> : <Empty>该项目没有公开工作流步骤。执行过委派或工作流的项目可生成完整配方。</Empty>}
      </article> : <div className="pr-card"><Empty>选择一个配方查看步骤。</Empty></div>}
    </div>
  </section>
}

function ScheduleForm({ projects, recipes, initialProject = '', initialRecipe = '', busy, onClose, onSubmit }: { projects: ProjectRecord[]; recipes: RecipeRecord[]; initialProject?: string; initialRecipe?: string; busy: boolean; onClose(): void; onSubmit(value: unknown): Promise<void> }) {
  const source = recipes.find(r => r.id === initialRecipe)?.sourceProjectId
  const initialProjectId = initialProject || (initialRecipe ? projects.find(p => p.id === source)?.id ?? '' : projects[0]?.id ?? '')
  const [projectId, setProjectId] = React.useState(initialProjectId), [recipeId, setRecipeId] = React.useState(initialRecipe), [recipeUse, setRecipeUse] = React.useState<RecipeUse>('fixed'), [target, setTarget] = React.useState<'append' | 'new'>(initialRecipe ? 'new' : 'append')
  const [kind, setKind] = React.useState<ScheduleKind>('daily'), [time, setTime] = React.useState('09:00'), [zone, setZone] = React.useState(Intl.DateTimeFormat().resolvedOptions().timeZone || 'Asia/Taipei'), [weekdays, setWeekdays] = React.useState<number[]>([1]), [hours, setHours] = React.useState('24'), [minutes, setMinutes] = React.useState('2'), [cron, setCron] = React.useState('0 9 * * *'), [name, setName] = React.useState(''), [prompt, setPrompt] = React.useState('')
  const valid = (projectId || (target === 'new' && recipeId)) && (kind !== 'weekly' || weekdays.length > 0) && (!['daily', 'weekly', 'cron'].includes(kind) || zone.trim())
  return <form className="pr-card pr-schedule-form" aria-label="创建定时任务" onSubmit={e => {
    e.preventDefault(); const calendar = { time: `${time}:00`, time_zone: zone.trim() }
    const selector = kind === 'daily' ? { daily: calendar } : kind === 'weekly' ? { weekly: { ...calendar, weekdays: [...weekdays].sort() } } : kind === 'every' ? { every_seconds: Math.round(Number(hours) * 3600) } : kind === 'after' ? { after_seconds: Math.round(Number(minutes) * 60) } : { cron: { expression: cron.trim(), time_zone: zone.trim() } }
    void onSubmit({ ...(projectId ? { projectId } : {}), target, ...(recipeId ? { recipeId, recipeUse } : {}), ...(name.trim() ? { title: name.trim() } : {}), ...(prompt.trim() ? { prompt: prompt.trim() } : {}), ...selector })
  }}><div className="pr-section-title"><h3>创建定时任务</h3><button type="button" aria-label="关闭定时表单" onClick={onClose}>×</button></div>
    <div className="pr-form-grid"><Field label="项目"><select required={target === 'append' || !recipeId} value={projectId} onChange={e => setProjectId(e.target.value)}><option value="">{target === 'new' && recipeId ? '直接使用所选配方' : '选择项目'}</option>{projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select></Field><Field label="执行方式"><select value={target} onChange={e => setTarget(e.target.value as any)}><option value="append">固定项目追加一轮</option><option value="new">每次新建项目</option></select></Field></div>
    <div className={recipeId ? 'pr-form-grid' : undefined}><Field label="运行配方"><select value={recipeId} onChange={e => setRecipeId(e.target.value)}><option value="">沿用项目配方与需求</option>{recipes.map(r => <option key={r.id} value={r.id}>{r.name}</option>)}</select></Field>{recipeId && <Field label="配方执行方式"><select value={recipeUse} onChange={e => setRecipeUse(e.target.value as RecipeUse)}><option value="fixed">固定执行</option><option value="reference">作为参考</option></select></Field>}</div>
    <div className="pr-form-grid"><Field label="频率"><select value={kind} onChange={e => setKind(e.target.value as ScheduleKind)}><option value="daily">每天</option><option value="weekly">每周</option><option value="every">每 N 小时</option><option value="cron">Cron 表达式</option><option value="after">延迟一次</option></select></Field>
      {(kind === 'daily' || kind === 'weekly') && <Field label="当地时间"><input type="time" required value={time} onChange={e => setTime(e.target.value)}/></Field>}{kind === 'every' && <Field label="间隔小时"><input type="number" min="0.016667" step="any" required value={hours} onChange={e => setHours(e.target.value)}/></Field>}{kind === 'after' && <Field label="多少分钟后"><input type="number" min="0.016667" step="any" required value={minutes} onChange={e => setMinutes(e.target.value)}/></Field>}{kind === 'cron' && <Field label="Cron（分 时 日 月 星期）"><input required value={cron} onChange={e => setCron(e.target.value)}/></Field>}
    </div>
    {kind === 'weekly' && <fieldset className="pr-weekdays"><legend>星期</legend>{['一', '二', '三', '四', '五', '六', '日'].map((day, i) => <label key={day}><input type="checkbox" checked={weekdays.includes(i + 1)} onChange={e => setWeekdays(days => e.target.checked ? [...days, i + 1] : days.filter(v => v !== i + 1))}/>{day}</label>)}</fieldset>}
    {['daily', 'weekly', 'cron'].includes(kind) && <Field label="时区"><input required value={zone} onChange={e => setZone(e.target.value)} placeholder="Asia/Taipei"/></Field>}
    <Field label="任务名称（可选）"><input maxLength={120} value={name} onChange={e => setName(e.target.value)} placeholder="例如：每日更新项目"/></Field><Field label="本轮需求（可选）"><textarea rows={2} value={prompt} onChange={e => setPrompt(e.target.value)} placeholder="留空沿用项目需求"/></Field>
    <div className="pr-form-footer"><small>{target === 'new' ? '每次到点创建独立项目与主会话。' : '到点向项目主会话追加一轮需求。'}</small><button className="pr-primary" type="submit" disabled={busy || !valid}>创建定时</button></div>
  </form>
}
function timing(schedule: ScheduleRecord): string {
  const s = schedule.selector as any
  if (schedule.kind === 'every') return `每 ${Number(s.every_seconds) / 3600} 小时`
  if (schedule.kind === 'after') return `${Number(s.after_seconds) / 60} 分钟后一次`
  if (schedule.kind === 'daily') return `每天 ${s.daily?.time ?? ''} · ${s.daily?.time_zone ?? ''}`
  if (schedule.kind === 'weekly') return `每周 ${(s.weekly?.weekdays ?? []).map((n: number) => ['一','二','三','四','五','六','日'][n - 1]).join('、')} ${s.weekly?.time ?? ''} · ${s.weekly?.time_zone ?? ''}`
  return `Cron ${typeof s.cron === 'string' ? s.cron : `${s.cron?.expression ?? ''} · ${s.cron?.time_zone ?? ''}`}`
}
function Schedules({ projects, recipes, schedules, showForm, initialRecipe, onToggle, call, run, busy, changed, notice }: { projects: ProjectRecord[]; recipes: RecipeRecord[]; schedules: ScheduleRecord[]; showForm: boolean; initialRecipe: string; onToggle(): void; call: ProjectsActions['call']; run: Run; busy: boolean; changed(): Promise<void>; notice(value: string): void }) {
  const [confirm, setConfirm] = React.useState('')
  return <section data-testid="schedules-view"><div className="pr-section-title pr-view-heading"><div><h2>定时运行</h2><p>按时继续当前项目，或创建一轮全新的项目。</p></div><button className="pr-primary" disabled={!projects.length && !recipes.length} onClick={onToggle}>{showForm ? '收起表单' : '＋ 创建定时'}</button></div>
    {showForm && <ScheduleForm projects={projects} recipes={recipes} initialRecipe={initialRecipe} busy={busy} onClose={onToggle} onSubmit={request => run('正在创建定时', async () => { await call('schedule', request); await changed(); onToggle(); notice('定时任务已创建。') })}/>}
    <div className="pr-schedules">{schedules.length ? schedules.map(schedule => <article className="pr-card pr-schedule-card" key={schedule.id}><div className="pr-section-title"><h3>{schedule.title}</h3><div className="pr-actions"><span className="pr-badge">{schedule.target === 'new' ? '每次新建项目' : '追加一轮'}</span><Badge value={schedule.status ?? 'unknown'}/></div></div><p className="pr-schedule-timing">◷ {timing(schedule)}</p><p>{projects.find(p => p.id === schedule.projectId)?.name ?? '项目'}{schedule.recipeId ? ` · ${recipes.find(r => r.id === schedule.recipeId)?.name ?? '已保存配方'}` : ''}</p><p className="pr-muted">{schedule.prompt}</p><div className="pr-form-footer"><small>{schedule.nextRun ? `${schedule.status === 'active' ? '下次运行' : '计划时间'}：${dt(schedule.nextRun)}` : `创建于 ${dt(schedule.createdAt)}`}</small>{confirm === schedule.id ? <div className="pr-actions"><span>删除这个定时？</span><button onClick={() => setConfirm('')}>取消</button><button className="pr-danger" disabled={busy} onClick={() => void run('正在删除定时', async () => { await call('deleteSchedule', { scheduleId: schedule.id }); await changed(); setConfirm(''); notice('定时任务已删除。') })}>确认删除</button></div> : <button onClick={() => setConfirm(schedule.id)}>删除定时</button>}</div></article>) : <div className="pr-card"><Empty>{projects.length ? '还没有定时任务。创建后可在这里查看和删除。' : '先创建一个项目，再安排下一次运行。'}</Empty></div>}</div>
  </section>
}
