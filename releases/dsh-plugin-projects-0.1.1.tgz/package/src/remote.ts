/** Shared strict Remote contract for the Projects Host and Web client. */
import { z } from 'zod'
import { createTypertRemoteInfo } from '@deepseek-ai/dsh-typert-protocol/remote-info'

const string = z.string().min(1)
const projectId = z.strictObject({ projectId: string })
const recipeId = z.strictObject({ recipeId: string })
const use = z.enum(['reference', 'fixed'])
const daily = z.strictObject({ time: string, time_zone: string })
const weekly = daily.extend({ weekdays: z.array(z.number().int().min(1).max(7)).min(1).max(7) })
const cron = z.union([string, z.strictObject({ expression: string, time_zone: string })])
const schemas = {
  get: projectId,
  create: z.strictObject({ name: string, prompt: string, recipeId: string.optional(), recipeUse: use.optional() }),
  deliver: projectId.extend({
    summary: z.string().optional(),
    selfTest: z.strictObject({ passed: z.boolean(), command: z.string().optional(), output: z.json().optional() }).optional(),
    humanChecks: z.array(z.string()).optional(),
  }),
  saveRecipe: projectId.extend({ name: string.optional(), description: z.string().optional() }),
  renameRecipe: recipeId.extend({ name: string.optional(), description: z.string().optional() }),
  deleteRecipe: recipeId,
  exportRecipe: recipeId,
  importRecipe: z.strictObject({ json: string }),
  runRecipe: recipeId.extend({ use, projectId: string.optional(), prompt: z.string().optional() }),
  schedule: z.strictObject({
    projectId: string.optional(), recipeId: string.optional(),
    title: z.string().max(120).optional(), prompt: z.string().optional(), target: z.enum(['append', 'new']).optional(), recipeUse: use.optional(),
    after_seconds: z.number().int().positive().optional(), every_seconds: z.number().int().min(60).optional(),
    daily: daily.optional(), weekly: weekly.optional(), cron: cron.optional(),
  }),
  deleteSchedule: z.strictObject({ scheduleId: string }),
  uiCheck: z.strictObject({
    root: string, steps: z.union([z.string(), z.array(z.json())]),
    page: z.string().optional(), out: z.string().optional(), shot: z.string().optional(),
  }),
}

const descriptions: Record<string, string> = {
  list: 'List Projects with their public board and delivery state.',
  get: 'Read one Project.', create: 'Create a workspace-backed Project and start its main Session.',
  deliver: 'Record the Project delivery card.', saveRecipe: 'Save the public workflow sequence as a recipe.',
  recipes: 'List saved recipes.', renameRecipe: 'Rename a recipe.', deleteRecipe: 'Delete a recipe.',
  exportRecipe: 'Export one recipe as JSON.', importRecipe: 'Import a recipe JSON document.',
  runRecipe: 'Run a recipe against a Project.', schedule: 'Create a DSH schedule for a Project.',
  schedules: 'List Projects schedules.', deleteSchedule: 'Delete one Projects schedule.',
  uiCheck: 'Run the local headless UI checker for a Project.',
}

const methods = Object.fromEntries(Object.entries(descriptions).map(([method, description]) => {
  const schema = schemas[method as keyof typeof schemas]
  const inputCodec = schema === undefined ? undefined : {
    mode: 'strict' as const, typeSymbol: `dsh-plugin-projects#${method}:request`, create: () => schema,
    jsonSchema: z.toJSONSchema(schema, { target: 'draft-7' }),
  }
  return [`projects/${method}`, {
    service: 'projects', description, invocation: { kind: 'direct' as const },
    ...(method === 'uiCheck' ? { cancellation: { parameter: 'signal' as const } } : {}),
    parameters: inputCodec === undefined ? [] : [{ name: 'request', source: 'json' as const, codec: inputCodec, strictCodec: inputCodec }],
    result: { mode: 'strict' as const, typeSymbol: `dsh-plugin-projects#${method}:result`, create: () => z.json() },
  }]
}))

/** Mount with `ctx.remote.$mount(TYPERT_REMOTE)` before using `remote.projects`. */
export const TYPERT_REMOTE = createTypertRemoteInfo({ package: 'dsh-plugin-projects', methods }, z)
export default TYPERT_REMOTE
