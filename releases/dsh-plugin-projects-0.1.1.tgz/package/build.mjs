/** Reproducible package-local build. Install dev dependencies with --ignore-scripts. */
import { build } from 'esbuild'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { createRequire } from 'node:module'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = dirname(fileURLToPath(import.meta.url))
const require = createRequire(import.meta.url)
const resolveDependency = specifier => require.resolve(specifier)
const common = { absWorkingDir: root, bundle: true, target: 'es2022', charset: 'utf8', logLevel: 'info' }
await mkdir(join(root, 'lib'), { recursive: true })
await build({ ...common, entryPoints: ['src/remote.ts'], platform: 'neutral', format: 'esm', packages: 'external', outfile: 'lib/typert.remote-client.js' })
if (!process.argv.includes('--metadata-only')) {
  await build({ ...common, entryPoints: ['src/index.ts'], platform: 'node', format: 'esm', packages: 'external', outfile: 'lib/index.js' })
  const client = await build({
    ...common, entryPoints: ['src/client/index.ts'], platform: 'browser', format: 'cjs', write: false,
    jsx: 'transform', jsxFactory: 'React.createElement', jsxFragment: 'React.Fragment',
    tsconfigRaw: { compilerOptions: { jsx: 'react' } },
    external: ['react', 'react-dom', 'react/jsx-runtime'],
    plugins: [{ name: 'projects-public-dependencies', setup(builder) {
      builder.onResolve({ filter: /^@deepseek-ai\// }, args => args.path === '@deepseek-ai/dsh-typert-protocol/remote-info'
        ? { path: resolveDependency(args.path) }
        : { path: args.path, external: true })
      builder.onResolve({ filter: /^zod(?:\/.*)?$/ }, args => ({ path: resolveDependency(args.path) }))
    } }],
  })
  const body = client.outputFiles[0].text
  await writeFile(join(root, 'lib/client.js'), `window.__ModuleLoader__.load({id:"dsh-plugin-projects",factory:(require)=>{var module={exports:{}};var exports=module.exports;\n${body}\nreturn module.exports;}});\n`, 'utf8')
}

// The vocabulary is declaration-only TypeScript, so it can be copied exactly.
await mkdir(join(root, 'lib/types/client'), { recursive: true })
const vocabulary = await readFile(join(root, 'src/types.ts'), 'utf8')
await writeFile(join(root, 'lib/types/types.d.ts'), vocabulary.replaceAll("import('./types.ts')", "import('./types.js')"), 'utf8')
