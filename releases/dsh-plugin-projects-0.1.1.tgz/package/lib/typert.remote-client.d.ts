import type { RemoteResult, TypertRemoteInfo } from '@deepseek-ai/dsh-typert-protocol'
import type { DeliveryCard, ProjectRecord, RecipeRecord, ScheduleRecord } from './types/types.js'
import type { CreateProjectRequest, DeliverRequest, ProjectIdRequest, RenameRecipeRequest, RunRecipeRequest, SaveRecipeRequest, ScheduleProjectRequest, UiCheckRequest } from './types/requests.js'
export interface ProjectsRemote {
  list(): Promise<RemoteResult<readonly ProjectRecord[]>>
  get(request: ProjectIdRequest): Promise<RemoteResult<ProjectRecord>>
  create(request: CreateProjectRequest): Promise<RemoteResult<ProjectRecord>>
  deliver(request: DeliverRequest): Promise<RemoteResult<DeliveryCard>>
  saveRecipe(request: SaveRecipeRequest): Promise<RemoteResult<RecipeRecord>>
  recipes(): Promise<RemoteResult<readonly RecipeRecord[]>>
  renameRecipe(request: RenameRecipeRequest): Promise<RemoteResult<RecipeRecord>>
  deleteRecipe(request: { readonly recipeId: string }): Promise<RemoteResult<{ deleted: boolean }>>
  exportRecipe(request: { readonly recipeId: string }): Promise<RemoteResult<string>>
  importRecipe(request: { readonly json: string }): Promise<RemoteResult<RecipeRecord>>
  runRecipe(request: RunRecipeRequest): Promise<RemoteResult<Record<string, unknown>>>
  schedule(request: ScheduleProjectRequest): Promise<RemoteResult<ScheduleRecord>>
  schedules(): Promise<RemoteResult<readonly ScheduleRecord[]>>
  deleteSchedule(request: { readonly scheduleId: string }): Promise<RemoteResult<{ deleted: boolean }>>
  uiCheck(request: UiCheckRequest, signal?: AbortSignal): Promise<RemoteResult<unknown>>
}
declare module '@deepseek-ai/dsh-typert-protocol' {
  interface TypertRemoteNamespaceMap { projects: ProjectsRemote }
  interface TypertRemoteMap {
    'projects/list': ProjectsRemote['list']; 'projects/get': ProjectsRemote['get']; 'projects/create': ProjectsRemote['create']
    'projects/deliver': ProjectsRemote['deliver']; 'projects/saveRecipe': ProjectsRemote['saveRecipe']; 'projects/recipes': ProjectsRemote['recipes']
    'projects/renameRecipe': ProjectsRemote['renameRecipe']; 'projects/deleteRecipe': ProjectsRemote['deleteRecipe']; 'projects/exportRecipe': ProjectsRemote['exportRecipe']
    'projects/importRecipe': ProjectsRemote['importRecipe']; 'projects/runRecipe': ProjectsRemote['runRecipe']; 'projects/schedule': ProjectsRemote['schedule']
    'projects/schedules': ProjectsRemote['schedules']; 'projects/deleteSchedule': ProjectsRemote['deleteSchedule']; 'projects/uiCheck': ProjectsRemote['uiCheck']
  }
}
export declare const TYPERT_REMOTE: TypertRemoteInfo
export default TYPERT_REMOTE
