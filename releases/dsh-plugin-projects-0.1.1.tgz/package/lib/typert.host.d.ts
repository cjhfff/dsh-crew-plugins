import type { TypertContribution } from '@deepseek-ai/dsh-typert-registry'
export declare const TYPERT: TypertContribution
