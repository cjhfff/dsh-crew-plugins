/** JSON-safe public vocabulary owned by the Projects plugin. */
export type ProjectStatus = 'running' | 'waiting' | 'delivered' | 'failed'
export type RecipeUse = 'reference' | 'fixed'
export type ScheduleTarget = 'append' | 'new'
export type ScheduleKind = 'daily' | 'weekly' | 'every' | 'cron' | 'after'

export interface BoardState {
  readonly plan: readonly unknown[]
  readonly todos: readonly unknown[]
  readonly deliverables: readonly { path: string; description?: string }[]
  readonly workflow: readonly PublicWorkflowEvent[]
}

export interface PublicWorkflowEvent {
  readonly type: string
  readonly runId?: string
  readonly childId?: string
  readonly label?: string
  readonly phase?: string
  readonly status?: string
  readonly at?: string
  readonly detail?: string
  readonly seq?: number
  readonly task?: string
  readonly actor?: string
}

export interface ProjectRecord {
  readonly id: string
  readonly name: string
  readonly slug: string
  readonly path: string
  readonly workspaceId: string
  readonly sessionId: string
  readonly prompt: string
  readonly createdAt: string
  readonly updatedAt: string
  readonly status: ProjectStatus
  readonly board: BoardState
  readonly delivery?: DeliveryCard
  readonly recipeId?: string
  readonly lastError?: string
}

export interface DeliveryCard {
  readonly projectId: string
  readonly title: string
  readonly summary: string
  readonly openPath: string
  readonly selfTest: { readonly passed: boolean; readonly command?: string; readonly output?: unknown }
  readonly humanChecks: readonly string[]
  readonly files: readonly { readonly path: string; readonly description?: string }[]
  readonly createdAt: string
}

export interface RecipeStep {
  readonly id: string
  readonly kind: 'agent' | 'workflow' | 'phase' | 'log'
  readonly label: string
  readonly dependsOn: readonly string[]
  readonly publicEvent: string
  readonly task?: string
  readonly actor?: string
  readonly phase?: string
  readonly sourceSessionId?: string
}

export interface RecipeRecord {
  readonly id: string
  readonly name: string
  readonly description: string
  readonly steps: readonly RecipeStep[]
  readonly sourceProjectId?: string
  readonly createdAt: string
  readonly updatedAt: string
}

export interface ScheduleRecord {
  readonly id: string
  readonly projectId?: string
  readonly recipeId?: string
  readonly sessionId: string
  readonly target: ScheduleTarget
  readonly kind: ScheduleKind
  readonly title: string
  readonly prompt: string
  readonly selector: Record<string, unknown>
  readonly createdAt: string
  readonly nextRun?: string
  readonly status?: 'active' | 'inactive'
  readonly recipeUse?: RecipeUse
  readonly lastMessageId?: string
  readonly lastProjectId?: string
}

export interface ProjectsConfig {
  readonly projectsRoot?: string
  readonly dataDir?: string
  readonly leaderPreset?: string | null
  readonly uiCheckCommand?: string
  readonly scheduleSessionTitle?: string
  readonly uiCheckTimeoutMs?: number
}

/** Public projection merge consumed by the DSH session client. */
declare module '@deepseek-ai/dsh-session-projection/types' {
  interface SessionProjectionStateMap {
    projectsBoard: import('./types.js').BoardState
  }
  interface SessionProjectionMap {
    projectsBoard: import('./types.js').BoardState
  }
}
