import type { Context } from '@deepseek-ai/cordis'
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol'
import type z from '@deepseek-ai/schemastery'
import type { DeliveryCard, ProjectRecord, ProjectsConfig, RecipeRecord, ScheduleRecord } from './types.js'
import type { CreateProjectRequest, DeliverRequest, ProjectIdRequest, RenameRecipeRequest, RunRecipeRequest, SaveRecipeRequest, ScheduleProjectRequest, UiCheckRequest } from './requests.js'
export type * from './types.js'
export type * from './requests.js'
export declare class ProjectsService extends TypertRemoteService {
  static inject: string[]
  static Config: z<ProjectsConfig>
  readonly config: Required<ProjectsConfig>
  constructor(ctx: Context, config?: ProjectsConfig)
  list(): Promise<readonly ProjectRecord[]>
  get(request: ProjectIdRequest): Promise<ProjectRecord>
  create(request: CreateProjectRequest): Promise<ProjectRecord>
  deliver(request: DeliverRequest): Promise<DeliveryCard>
  saveRecipe(request: SaveRecipeRequest): Promise<RecipeRecord>
  recipes(): Promise<readonly RecipeRecord[]>
  renameRecipe(request: RenameRecipeRequest): Promise<RecipeRecord>
  deleteRecipe(request: { readonly recipeId: string }): Promise<{ deleted: boolean }>
  exportRecipe(request: { readonly recipeId: string }): Promise<string>
  importRecipe(request: { readonly json: string }): Promise<RecipeRecord>
  runRecipe(request: RunRecipeRequest): Promise<Record<string, unknown>>
  schedule(request: ScheduleProjectRequest): Promise<ScheduleRecord>
  schedules(): Promise<readonly ScheduleRecord[]>
  deleteSchedule(request: { readonly scheduleId: string }): Promise<{ deleted: boolean }>
  uiCheck(request: UiCheckRequest, signal?: AbortSignal): Promise<unknown>
}
declare module '@deepseek-ai/cordis' { interface Context { projects: ProjectsService } }
export declare const name: 'dsh-plugin-projects'
export declare const inject: string[]
export declare function apply(ctx: Context, config?: ProjectsConfig): void
export default ProjectsService
