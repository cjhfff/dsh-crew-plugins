import type { DeliveryCard, RecipeUse } from './types.js'
export interface CreateProjectRequest { readonly name: string; readonly prompt: string; readonly recipeId?: string; readonly recipeUse?: RecipeUse }
export interface ProjectIdRequest { readonly projectId: string }
export interface SaveRecipeRequest extends ProjectIdRequest { readonly name?: string; readonly description?: string }
export interface RenameRecipeRequest { readonly recipeId: string; readonly name?: string; readonly description?: string }
export interface RunRecipeRequest { readonly recipeId: string; readonly use: RecipeUse; readonly projectId?: string; readonly prompt?: string }
export interface DeliverRequest extends ProjectIdRequest { readonly summary?: string; readonly selfTest?: DeliveryCard['selfTest']; readonly humanChecks?: readonly string[] }
export interface ScheduleProjectRequest {
  readonly projectId?: string; readonly recipeId?: string; readonly recipeUse?: RecipeUse
  readonly title?: string; readonly prompt?: string; readonly target?: 'append' | 'new'
  readonly after_seconds?: number; readonly every_seconds?: number
  readonly daily?: { readonly time: string; readonly time_zone: string }
  readonly weekly?: { readonly time: string; readonly time_zone: string; readonly weekdays: readonly number[] }
  readonly cron?: string | { readonly expression: string; readonly time_zone: string }
}
export interface UiCheckRequest { readonly root: string; readonly steps: string | readonly unknown[]; readonly page?: string; readonly out?: string; readonly shot?: string }
